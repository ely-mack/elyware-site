/**
 * Gapless video-loop helper.
 *
 * Browsers can briefly expose an empty decoder frame when a single <video>
 * seeks from its end back to zero. SeamlessVideoLoop keeps a second decoder
 * parked on the first frame, starts it shortly before the active decoder ends,
 * and exposes an eased blend that canvas renderers can composite without a
 * black frame between cycles.
 */
(function installSeamlessVideoLoop(global) {
    'use strict';

    const DEFAULT_FADE_SECONDS = 0.75;
    const MIN_FADE_SECONDS = 0.08;

    function clamp01(value) {
        return Math.max(0, Math.min(1, Number(value) || 0));
    }

    function smoothstep(value) {
        const t = clamp01(value);
        return t * t * (3 - 2 * t);
    }

    function safePause(video) {
        try { video.pause(); } catch (error) {}
    }

    function safeLoad(video) {
        try { video.load(); } catch (error) {}
    }

    function safeSeek(video, seconds) {
        try { video.currentTime = Math.max(0, Number(seconds) || 0); } catch (error) {}
    }

    function safePlay(video) {
        try {
            const result = video.play();
            if (result && typeof result.catch === 'function') result.catch(() => {});
        } catch (error) {}
    }

    class SeamlessVideoLoop {
        constructor(primaryVideo, options = {}) {
            if (!primaryVideo) throw new Error('SeamlessVideoLoop requires a video element');

            const createVideo = options.createVideo || (() => document.createElement('video'));
            this.videos = [primaryVideo, createVideo()];
            this.activeIndex = 0;
            this.fadeSeconds = Math.max(MIN_FADE_SECONDS,
                Number(options.fadeSeconds) || DEFAULT_FADE_SECONDS);
            this.shouldLoop = typeof options.shouldLoop === 'function'
                ? options.shouldLoop
                : () => Boolean(options.loop);
            this.onEnded = typeof options.onEnded === 'function' ? options.onEnded : () => {};
            this.onActiveChange = typeof options.onActiveChange === 'function'
                ? options.onActiveChange
                : () => {};
            this.onLoop = typeof options.onLoop === 'function' ? options.onLoop : () => {};

            this.source = '';
            this.transitioning = false;
            this.pendingPromotion = false;
            this.mix = 0;
            this.cycle = 0;
            this.volume = 1;
            this.playbackRate = 1;
            this.playing = false;

            this.videos.forEach(video => {
                video.playsInline = true;
                video.preload = 'auto';
                video.addEventListener('timeupdate', () => {
                    if (video === this.active) this.update();
                });
                video.addEventListener('ended', () => this._handleEnded(video));
                const finishPendingLoop = () => {
                    if (video === this.standby && this.pendingPromotion && this._isReady(video)) {
                        this._promoteStandby();
                    }
                };
                video.addEventListener('loadeddata', finishPendingLoop);
                video.addEventListener('canplay', finishPendingLoop);
            });
        }

        get active() {
            return this.videos[this.activeIndex];
        }

        get standby() {
            return this.videos[1 - this.activeIndex];
        }

        get isLooping() {
            return Boolean(this.source && this.shouldLoop());
        }

        _fadeWindow() {
            const duration = Number(this.active.duration);
            if (!Number.isFinite(duration) || duration <= 0) return 0;
            // Keep the dissolve duration stable in wall-clock time when speed
            // changes, while never overlapping more than a quarter of a clip.
            return Math.min(this.fadeSeconds * this.playbackRate, duration * 0.25);
        }

        _isReady(video) {
            return Boolean(video && video.readyState >= 2);
        }

        setSource(source) {
            this.source = String(source || '');
            this.activeIndex = 0;
            this.transitioning = false;
            this.pendingPromotion = false;
            this.mix = 0;
            this.cycle = 0;
            this.playing = false;

            for (const video of this.videos) {
                safePause(video);
                video.removeAttribute('src');
                safeLoad(video);
                if (this.source) {
                    video.src = this.source;
                    video.preload = 'auto';
                    video.playbackRate = this.playbackRate;
                    safeLoad(video);
                }
            }
            this._applyVolumes();
            this.onActiveChange(this.active, null);
        }

        clearSource() {
            this.setSource('');
        }

        play() {
            this.playing = true;
            if (this.source) safePlay(this.active);
            if (this.transitioning) safePlay(this.standby);
        }

        pause() {
            this.playing = false;
            this.videos.forEach(safePause);
        }

        setPlaybackRate(rate) {
            const next = Number(rate);
            this.playbackRate = Number.isFinite(next) && next > 0 ? next : 1;
            for (const video of this.videos) video.playbackRate = this.playbackRate;
        }

        setVolume(volume) {
            this.volume = clamp01(volume);
            this._applyVolumes();
        }

        setMuted(muted) {
            for (const video of this.videos) video.muted = Boolean(muted);
        }

        seek(seconds) {
            this._cancelTransition();
            safeSeek(this.active, seconds);
            safeSeek(this.standby, 0);
            if (this.playing) safePlay(this.active);
        }

        _applyVolumes() {
            const incoming = this.transitioning ? this.mix : 0;
            try { this.active.volume = this.volume * (1 - incoming); } catch (error) {}
            try { this.standby.volume = this.volume * incoming; } catch (error) {}
        }

        _startTransition() {
            if (this.transitioning || !this.isLooping || !this._isReady(this.standby)) return false;
            safePause(this.standby);
            safeSeek(this.standby, 0);
            this.standby.playbackRate = this.playbackRate;
            this.standby.muted = this.active.muted;
            this.transitioning = true;
            this.mix = 0;
            this._applyVolumes();
            if (this.playing) safePlay(this.standby);
            return true;
        }

        _cancelTransition() {
            if (!this.transitioning && !this.pendingPromotion && this.mix === 0) return;
            safePause(this.standby);
            safeSeek(this.standby, 0);
            this.transitioning = false;
            this.pendingPromotion = false;
            this.mix = 0;
            this._applyVolumes();
        }

        _promoteStandby() {
            if (!this._isReady(this.standby)) return false;
            const outgoing = this.active;
            const incoming = this.standby;

            this.mix = 1;
            this._applyVolumes();
            this.activeIndex = 1 - this.activeIndex;
            this.cycle += 1;
            this.transitioning = false;
            this.pendingPromotion = false;
            this.mix = 0;

            safePause(outgoing);
            safeSeek(outgoing, 0);
            outgoing.playbackRate = this.playbackRate;
            incoming.playbackRate = this.playbackRate;
            this._applyVolumes();
            if (this.playing) safePlay(incoming);

            this.onActiveChange(incoming, outgoing);
            this.onLoop(this.cycle);
            return true;
        }

        _handleEnded(video) {
            // An outgoing decoder can dispatch its queued ended event after the
            // roles have already swapped. It must not advance the playlist.
            if (video !== this.active) return;

            if (!this.isLooping) {
                this.playing = false;
                this.onEnded();
                return;
            }

            if (!this.transitioning) this._startTransition();
            if (this._promoteStandby()) return;

            // Hold the outgoing decoder's last frame if the standby decoder is
            // unexpectedly late. Seeking the outgoing element here would
            // recreate the very black-frame gap this helper exists to prevent.
            this.pendingPromotion = true;
            safeLoad(this.standby);
        }

        update() {
            if (!this.source || !this.isLooping) {
                this._cancelTransition();
                return this.getBlend(false);
            }

            if (this.pendingPromotion) {
                if (this._promoteStandby()) return this.getBlend(false);
                return this.getBlend(false);
            }

            const duration = Number(this.active.duration);
            const fadeWindow = this._fadeWindow();
            if (!Number.isFinite(duration) || duration <= 0 || fadeWindow <= 0) {
                return this.getBlend(false);
            }

            const threshold = duration - fadeWindow;
            const currentTime = Number(this.active.currentTime) || 0;

            // A manual seek back out of the overlap restarts loop preparation.
            if (this.transitioning && currentTime < threshold - 0.05) {
                this._cancelTransition();
            }
            if (!this.transitioning && currentTime >= threshold && currentTime < duration) {
                this._startTransition();
            }
            if (this.transitioning) {
                this.mix = smoothstep((currentTime - threshold) / fadeWindow);
                this._applyVolumes();
            }

            return this.getBlend(false);
        }

        getBlend(runUpdate = true) {
            if (runUpdate) this.update();
            return {
                base: this._isReady(this.active) ? this.active : null,
                incoming: this.transitioning && this._isReady(this.standby) ? this.standby : null,
                mix: this.transitioning ? this.mix : 0,
                cycle: this.cycle,
            };
        }
    }

    function drawSeamlessVideoBlend(ctx, blend, canvasW, canvasH, drawFit) {
        if (!blend || !blend.base) return false;
        drawFit(ctx, blend.base, canvasW, canvasH);
        if (blend.incoming && blend.mix > 0) {
            ctx.save();
            ctx.globalAlpha = clamp01(blend.mix);
            drawFit(ctx, blend.incoming, canvasW, canvasH);
            ctx.restore();
        }
        return true;
    }

    global.SeamlessVideoLoop = SeamlessVideoLoop;
    global.drawSeamlessVideoBlend = drawSeamlessVideoBlend;
    global.SEAMLESS_LOOP_FADE_SECONDS = DEFAULT_FADE_SECONDS;
})(typeof window !== 'undefined' ? window : globalThis);
