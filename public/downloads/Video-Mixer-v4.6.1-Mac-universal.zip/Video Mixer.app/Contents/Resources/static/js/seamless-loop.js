/**
 * Gapless video-loop helper.
 *
 * A single <video> that seeks from its end back to zero briefly has no frame
 * to show, and a paused <video> takes a moment to start. SeamlessVideoLoop
 * hides both with a second decoder on the same clip:
 *
 *   - The standby decoder waits paused on frame 0.
 *   - Shortly before the active decoder runs out, the standby starts playing,
 *     early by exactly its measured start-up latency, so its first frame
 *     arrives as the active decoder's last frame ends.
 *   - Renderers then switch straight to it. No dissolve, no black frame, no
 *     held frame: a clip authored to loop stays frame-continuous, and any
 *     other clip gets a clean cut.
 *
 * The lead time is learned: every loop measures how long the standby took to
 * start and feeds that into the next one, so it converges on whatever the
 * machine, browser engine and clip resolution need.
 *
 * The second decoder is an optimization and is never trusted to show up.
 * A heartbeat keeps checking even when nothing renders. If the standby is
 * not ready within a quarter second of the loop point, or will not play,
 * the active decoder rewinds and keeps going instead (a short hitch, never
 * a freeze). After repeated failures the source loops on one decoder. A
 * decoder that should be playing but has stopped advancing gets restarted.
 */
(function installSeamlessVideoLoop(global) {
    'use strict';

    const INITIAL_LEAD_SECONDS = 0.12;   // first-loop guess at decoder start-up time
    const MIN_LEAD_SECONDS = 0.02;
    const MAX_LEAD_SECONDS = 0.6;
    const START_SLACK_SECONDS = 0.008;   // about half a display frame of scheduling slop
    const END_EPSILON = 0.004;           // this close to duration counts as the end
    const PARK_DELAY_MS = 200;           // rewind the old decoder after the cut, not during it
    const WARM_SECONDS = 1.0;            // make sure the standby is decodable this far ahead
    const PENDING_LIMIT_MS = 250;        // longest the last frame is held waiting for the standby
    const STALL_LIMIT_MS = 1000;         // playing but not advancing for this long is a stall
    const NUDGE_INTERVAL_MS = 250;       // at most one reload/seek kick per decoder per interval
    const HEARTBEAT_MS = 100;            // drives the loop when neither rAF nor timeupdate does
    const MAX_HANDOFF_FAILURES = 2;      // consecutive failed hand-offs before one-decoder mode

    const now = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
    const supportsFrameCallback = typeof HTMLVideoElement !== 'undefined'
        && typeof HTMLVideoElement.prototype.requestVideoFrameCallback === 'function';

    function clamp(value, lo, hi) {
        return Math.max(lo, Math.min(hi, value));
    }

    function clamp01(value) {
        return clamp(Number(value) || 0, 0, 1);
    }

    function safePause(video) {
        try { video.pause(); } catch (error) {}
    }

    function safeLoad(video) {
        try { video.load(); } catch (error) {}
    }

    function safeSeek(video, seconds) {
        try { video.currentTime = Math.max(0, Number(seconds) || 0); } catch (error) {}
    }

    function safePlay(video, onRejected) {
        try {
            const result = video.play();
            if (result && typeof result.catch === 'function') {
                result.catch(error => {
                    if (onRejected && !(error && error.name === 'AbortError')) onRejected(error);
                });
            }
        } catch (error) {
            if (onRejected) onRejected(error);
        }
    }

    class SeamlessVideoLoop {
        constructor(primaryVideo, options = {}) {
            if (!primaryVideo) throw new Error('SeamlessVideoLoop requires a video element');

            const createVideo = options.createVideo || (() => document.createElement('video'));
            this.videos = [primaryVideo, createVideo()];
            this.activeIndex = 0;
            this.shouldLoop = typeof options.shouldLoop === 'function'
                ? options.shouldLoop
                : () => Boolean(options.loop);
            this.onEnded = typeof options.onEnded === 'function' ? options.onEnded : () => {};
            this.onActiveChange = typeof options.onActiveChange === 'function'
                ? options.onActiveChange
                : () => {};
            this.onLoop = typeof options.onLoop === 'function' ? options.onLoop : () => {};

            this.source = '';
            this.cycle = 0;
            this.volume = 1;
            this.playbackRate = 1;
            this.playing = false;

            // Learned decoder start-up latency, kept across clips: it depends
            // mostly on the machine and engine, not on the source.
            this.leadSeconds = INITIAL_LEAD_SECONDS;
            this.prerolling = false;      // standby playing silently, about to take over
            this.pendingSwitch = false;   // active ended before the standby was ready
            this._probe = null;           // { video, startedAt } start-up latency measurement
            this._parkTimer = null;
            this._lastGood = null;

            // Recovery state. The standby decoder is never trusted to show up.
            this.singleDecoder = false;   // loop on one decoder after repeated hand-off failures
            this._handoffFailures = 0;
            this._pendingSince = 0;
            this._heartbeat = null;
            this._progressTime = -1;      // last seen active currentTime, for stall detection
            this._progressAt = 0;
            this._stallKicks = 0;
            this._nudgedAt = new WeakMap();
            this._errors = new WeakMap();

            this.videos.forEach(video => {
                video.playsInline = true;
                video.preload = 'auto';
                // Keeps the loop alive when rendering stops (hidden tab, no rAF).
                video.addEventListener('timeupdate', () => {
                    if (video === this.active) this.update();
                });
                video.addEventListener('ended', () => this._handleEnded(video));
                const finishPendingSwitch = () => {
                    if (this.pendingSwitch && video === this.standby) this._switch();
                };
                video.addEventListener('loadeddata', finishPendingSwitch);
                video.addEventListener('canplay', finishPendingSwitch);
                video.addEventListener('seeked', finishPendingSwitch);
                video.addEventListener('error', () => {
                    // A standby that cannot decode gets a few fresh starts, then
                    // is released so this source loops on the healthy decoder.
                    if (!this.source || this.singleDecoder || video !== this.standby) return;
                    const errors = (this._errors.get(video) || 0) + 1;
                    this._errors.set(video, errors);
                    if (errors >= 3) this._enterSingleDecoder();
                    else this._nudge(video);
                });
            });
        }

        get active() {
            return this.videos[this.activeIndex];
        }

        get standby() {
            return this.videos[1 - this.activeIndex];
        }

        get isLooping() {
            return Boolean(this.source && this.shouldLoop());
        }

        /** True while a loop hand-off is in flight. Callers avoid hard seeks then. */
        get transitioning() {
            return this.prerolling || this.pendingSwitch;
        }

        /** Loops are cut, never blended. Kept for callers that report it. */
        get mix() {
            return 0;
        }

        /** Has a frame to draw. A seeking decoder still shows its last frame. */
        _isReady(video) {
            return Boolean(video && video.readyState >= 2);
        }

        /** Settled on a frame and safe to hand the loop to. */
        _isPrimed(video) {
            return this._isReady(video) && !video.seeking;
        }

        setSource(source) {
            this.source = String(source || '');
            this.activeIndex = 0;
            this.cycle = 0;
            this.playing = false;
            this._resetHandoff();
            this._lastGood = null;
            this.singleDecoder = false;
            this._handoffFailures = 0;
            this._nudgedAt = new WeakMap();
            this._errors = new WeakMap();
            this._markProgress(0);
            this._stopHeartbeat();

            for (const video of this.videos) {
                safePause(video);
                video.removeAttribute('src');
                safeLoad(video);
                if (this.source) {
                    video.src = this.source;
                    video.preload = 'auto';
                    video.playbackRate = this.playbackRate;
                    safeLoad(video);
                }
            }
            this._applyVolumes();
            this.onActiveChange(this.active, null);
        }

        clearSource() {
            this.setSource('');
        }

        play() {
            this.playing = true;
            if (!this.source) return;
            this._markProgress(this.active.currentTime);
            safePlay(this.active);
            this._startHeartbeat();
        }

        pause() {
            this.playing = false;
            this._stopHeartbeat();
            this.videos.forEach(video => safePause(video));
            // Re-armed automatically once playback resumes inside the window.
            if (this.prerolling) this._cancelPreroll();
        }

        setPlaybackRate(rate) {
            const next = Number(rate);
            this.playbackRate = Number.isFinite(next) && next > 0 ? next : 1;
            for (const video of this.videos) video.playbackRate = this.playbackRate;
        }

        setVolume(volume) {
            this.volume = clamp01(volume);
            this._applyVolumes();
        }

        setMuted(muted) {
            for (const video of this.videos) video.muted = Boolean(muted);
        }

        seek(seconds) {
            this._cancelPreroll();
            this.pendingSwitch = false;
            safeSeek(this.active, seconds);
            this._markProgress(this.active.currentTime);
            if (!this.singleDecoder) this._park(this.standby, 0);
            if (this.playing) safePlay(this.active);
        }

        _applyVolumes() {
            // The standby is silent while it pre-rolls so its audio never doubles up.
            try { this.active.volume = this.volume; } catch (error) {}
            try { this.standby.volume = 0; } catch (error) {}
        }

        _resetHandoff() {
            clearTimeout(this._parkTimer);
            this._parkTimer = null;
            this.prerolling = false;
            this.pendingSwitch = false;
            this._probe = null;
        }

        _startHeartbeat() {
            if (this._heartbeat || typeof setInterval !== 'function') return;
            this._heartbeat = setInterval(() => this.update(), HEARTBEAT_MS);
        }

        _stopHeartbeat() {
            if (this._heartbeat) clearInterval(this._heartbeat);
            this._heartbeat = null;
        }

        _markProgress(seconds) {
            this._progressTime = Number(seconds) || 0;
            this._progressAt = now();
            this._stallKicks = 0;
        }

        /** Give a decoder a fresh start: reload it if broken, otherwise re-seek to force a decode. */
        _nudge(video, seconds = 0) {
            if (!video || !this.source) return;
            if (this.singleDecoder && video === this.standby) return;
            const t = now();
            const last = this._nudgedAt.get(video) || 0;
            if (t - last < NUDGE_INTERVAL_MS) return;
            this._nudgedAt.set(video, t);
            // NETWORK_NO_SOURCE, or idle with no data at all: it will not load on its own.
            const broken = video.error || video.networkState === 3 || !video.currentSrc
                || (video.readyState === 0 && video.networkState !== 2);
            if (broken) {
                safePause(video);
                video.src = this.source;
                video.preload = 'auto';
                video.playbackRate = this.playbackRate;
                safeLoad(video);
                if (video === this.active && this.playing) safePlay(video);
                return;
            }
            // Re-seeking restarts a seek in flight, so leave one alone.
            if (!video.seeking) safeSeek(video, seconds);
        }

        /** Stop using the standby for this source and free its decoder. */
        _enterSingleDecoder() {
            if (this.singleDecoder) return;
            this.singleDecoder = true;
            this.prerolling = false;
            this.pendingSwitch = false;
            this._probe = null;
            clearTimeout(this._parkTimer);
            this._parkTimer = null;
            const standby = this.standby;
            safePause(standby);
            standby.removeAttribute('src');
            safeLoad(standby);
        }

        /**
         * Loop on the active decoder: rewind it in place. Used when the standby
         * missed the hand-off, and for every loop in one-decoder mode.
         */
        _restartInPlace(handoffFailed) {
            const active = this.active;
            this.prerolling = false;
            this.pendingSwitch = false;
            this._probe = null;
            if (handoffFailed) {
                this._handoffFailures += 1;
                if (this._handoffFailures >= MAX_HANDOFF_FAILURES) {
                    this._enterSingleDecoder();
                } else {
                    safePause(this.standby);
                    this._nudgedAt.delete(this.standby);
                    this._nudge(this.standby, 0);
                }
            }
            safeSeek(active, 0);
            if (this.playing) safePlay(active);
            this._markProgress(0);
            this.cycle += 1;
            this.onLoop(this.cycle);
        }

        /** Move playback onto the standby and drop the active decoder. False if it cannot. */
        _rescueOntoStandby(seconds) {
            const other = this.standby;
            if (this.singleDecoder || !this._isReady(other)) return false;
            const stuck = this.active;
            this.activeIndex = 1 - this.activeIndex;
            this.prerolling = false;
            this.pendingSwitch = false;
            safeSeek(other, seconds);
            if (this.playing) safePlay(other);
            this._applyVolumes();
            this.onActiveChange(other, stuck);
            this._enterSingleDecoder();
            this._markProgress(seconds);
            return true;
        }

        /** A play() was refused (autoplay policy, decoder failure). */
        _playRejected(video) {
            if (!this.source || !this.playing) return;
            if (video === this.standby) {
                // Refused to pre-roll: loop on the active decoder from now on.
                this._enterSingleDecoder();
            } else if (video === this.active) {
                // The incoming decoder took over but will not run. Go back.
                this._rescueOntoStandby(Number(video.currentTime) || 0);
            }
        }

        /** The active decoder should be advancing. Kick it if it is not. */
        _watchStall(active, currentTime, atEnd) {
            if (!this.playing || atEnd || active.seeking || currentTime !== this._progressTime) {
                this._markProgress(currentTime);
                return;
            }
            if (now() - this._progressAt < STALL_LIMIT_MS) return;
            this._stallKicks += 1;
            this._progressAt = now();
            if (this._stallKicks === 1) {
                if (active.readyState < 2) this._nudge(active, currentTime);
                else safeSeek(active, currentTime);
                safePlay(active);
                return;
            }
            // Still frozen after a kick. If the other decoder is healthy, move
            // the loop onto it and stop relying on the broken one.
            if (this._rescueOntoStandby(currentTime)) return;
            this._nudgedAt.delete(active);
            this._nudge(active, currentTime);
            safePlay(active);
        }

        /** Pause the standby on frame 0, now or once the cut has settled. */
        _park(video, delayMs) {
            clearTimeout(this._parkTimer);
            this._parkTimer = null;
            const run = () => {
                this._parkTimer = null;
                if (video !== this.standby || this.prerolling) return;
                safePause(video);
                if (video.currentTime !== 0) safeSeek(video, 0);
            };
            if (delayMs > 0) this._parkTimer = setTimeout(run, delayMs);
            else run();
        }

        /** Start a decoder and measure how long it takes to begin advancing. */
        _startPlayback(video) {
            const probe = { video, startedAt: now() };
            this._probe = probe;
            if (supportsFrameCallback) {
                try {
                    video.requestVideoFrameCallback((time, meta) => {
                        this._recordLatency(probe, time, meta && meta.mediaTime);
                    });
                } catch (error) {}
            }
            safePlay(video, () => this._playRejected(video));
        }

        _recordLatency(probe, time, mediaTime) {
            if (!probe || this._probe !== probe) return;
            this._probe = null;
            // When did media time 0 reach the screen? If the first frame we hear
            // about is already past zero, playback really began a little earlier.
            const latency = (time - probe.startedAt) / 1000
                - (Number(mediaTime) || 0) / (this.playbackRate || 1);
            if (!Number.isFinite(latency) || latency < 0 || latency > 2) return;
            this.leadSeconds = clamp(this.leadSeconds * 0.5 + latency * 0.5,
                MIN_LEAD_SECONDS, MAX_LEAD_SECONDS);
        }

        _startPreroll() {
            const standby = this.standby;
            if (this.prerolling) return true;
            if (!this._isPrimed(standby)) return false;
            if (standby.currentTime !== 0) {
                safeSeek(standby, 0);   // not parked yet; ready again on the next frame
                return false;
            }
            clearTimeout(this._parkTimer);
            this._parkTimer = null;
            standby.playbackRate = this.playbackRate;
            standby.muted = this.active.muted;
            standby.volume = 0;
            this.prerolling = true;
            this._startPlayback(standby);
            return true;
        }

        _cancelPreroll() {
            if (!this.prerolling) return;
            this.prerolling = false;
            this._probe = null;
            this._park(this.standby, 0);
        }

        /** Hand the screen to the standby decoder at the loop point. */
        _switch() {
            const incoming = this.standby;
            if (!this._isPrimed(incoming)) {
                // Keep showing the outgoing decoder's last frame until it is,
                // but only briefly: update() gives up after PENDING_LIMIT_MS.
                if (!this.pendingSwitch) {
                    this.pendingSwitch = true;
                    this._pendingSince = now();
                }
                this._nudge(incoming, 0);
                return false;
            }
            const outgoing = this.active;
            // Missed the pre-roll window (hidden tab, very short clip): start now.
            if (incoming.paused && this.playing) this._startPlayback(incoming);

            this.activeIndex = 1 - this.activeIndex;
            this.cycle += 1;
            this.prerolling = false;
            this.pendingSwitch = false;
            this._handoffFailures = 0;
            this._markProgress(incoming.currentTime);
            safePause(outgoing);
            this._applyVolumes();
            this._park(outgoing, PARK_DELAY_MS);

            this.onActiveChange(incoming, outgoing);
            this.onLoop(this.cycle);
            return true;
        }

        _handleEnded(video) {
            // The outgoing decoder can dispatch a queued ended event after the
            // roles have swapped. It must not advance the playlist.
            if (video !== this.active) return;

            if (!this.isLooping) {
                this.playing = false;
                this._stopHeartbeat();
                this.onEnded();
                return;
            }
            if (this.singleDecoder) {
                this._restartInPlace(false);
                return;
            }
            if (!this.prerolling) this._startPreroll();
            this._switch();
        }

        update() {
            if (!this.source || !this.isLooping) {
                this._cancelPreroll();
                return;
            }

            const probe = this._probe;
            if (probe && probe.video.currentTime > 0) {
                // Fallback when frame callbacks are unavailable or slow to fire.
                this._recordLatency(probe, now(), probe.video.currentTime);
            }

            if (this.pendingSwitch) {
                if (this._switch()) return;
                // The standby did not make it. Rewind the active decoder rather
                // than hold its last frame indefinitely.
                if (now() - this._pendingSince > PENDING_LIMIT_MS) this._restartInPlace(true);
                return;
            }

            const active = this.active;
            const duration = Number(active.duration);
            if (!Number.isFinite(duration) || duration <= 0) return;
            const currentTime = Number(active.currentTime) || 0;
            const remaining = (duration - currentTime) / (this.playbackRate || 1);
            const atEnd = active.ended || currentTime >= duration - END_EPSILON;

            this._watchStall(active, currentTime, atEnd);

            if (this.singleDecoder) {
                if (this.playing && atEnd) this._restartInPlace(false);
                return;
            }

            if (this.prerolling) {
                // A manual seek back out of the window re-arms the hand-off later.
                if (remaining > this.leadSeconds + 0.3) {
                    this._cancelPreroll();
                    return;
                }
                if (atEnd) this._switch();
                return;
            }

            if (!this.playing || active.paused) return;
            if (remaining <= this.leadSeconds + START_SLACK_SECONDS) {
                if (this._startPreroll() && atEnd) this._switch();
            } else if (remaining <= WARM_SECONDS && !this._isPrimed(this.standby)) {
                // A parked decoder can drop its frame (memory pressure, power
                // saving). Make it decode again before it is needed.
                this._nudge(this.standby, 0);
            }
        }

        getBlend(runUpdate = true) {
            if (runUpdate) this.update();
            let base = this._isReady(this.active) ? this.active : null;
            if (base) {
                this._lastGood = base;
            } else if (this._lastGood && this._isReady(this._lastGood)) {
                // Never flash black while a decoder settles; repeat its last frame.
                base = this._lastGood;
            }
            return { base, incoming: null, mix: 0, cycle: this.cycle };
        }
    }

    function drawSeamlessVideoBlend(ctx, blend, canvasW, canvasH, drawFit) {
        if (!blend || !blend.base) return false;
        drawFit(ctx, blend.base, canvasW, canvasH);
        if (blend.incoming && blend.mix > 0) {
            ctx.save();
            ctx.globalAlpha = clamp01(blend.mix);
            drawFit(ctx, blend.incoming, canvasW, canvasH);
            ctx.restore();
        }
        return true;
    }

    global.SeamlessVideoLoop = SeamlessVideoLoop;
    global.drawSeamlessVideoBlend = drawSeamlessVideoBlend;
    // Loops cut on the frame; there is no dissolve any more.
    global.SEAMLESS_LOOP_FADE_SECONDS = 0;
})(typeof window !== 'undefined' ? window : globalThis);
