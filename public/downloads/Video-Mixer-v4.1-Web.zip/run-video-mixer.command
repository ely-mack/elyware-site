#!/bin/bash
# Video Mixer — Web Edition
# Double-click to launch. Works on any Mac with Python 3.
# No installation or dependencies needed!

cd "$(dirname "$0")"

echo ""
echo "  ===================================="
echo "     VIDEO MIXER — Web Edition"
echo "  ===================================="
echo ""

# Check for Python 3
if ! command -v python3 &>/dev/null; then
    echo "  Python 3 not found. Please install it from:"
    echo "  https://www.python.org/downloads/"
    echo ""
    read -p "  Press Enter to open the download page..."
    open "https://www.python.org/downloads/"
    exit 1
fi

echo "  Python: $(python3 --version)"
echo "  Starting Video Mixer..."
echo ""

python3 video_mixer_web.py
