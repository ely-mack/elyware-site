#!/usr/bin/env python3
"""
ELYWARE Video Mixer v4.1 — Web Edition (Zero Dependencies)
Runs on any system with Python 3. No pip install needed.
Works on Mac, Windows, and Linux.
"""

VERSION = "4.1"

import os
import sys
import json
import glob
import mimetypes
import re
import threading
import webbrowser
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote
from stock_provider import StockProviderError, stock_provider, validate_local_origin

PORT = 5555
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MEDIA_EXTENSIONS = {
    'video': {'.mp4', '.mov', '.webm', '.m4v', '.ogv', '.mkv'},
    'image': {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.tiff', '.tif'},
}
ALL_MEDIA = MEDIA_EXTENSIONS['video'] | MEDIA_EXTENSIONS['image']
TRANSITIONS_DIR = os.path.expanduser('~/VideoMixer/transitions')

MIME_MAP = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
    '.svg': 'image/svg+xml',
    '.mp4': 'video/mp4',
    '.mov': 'video/quicktime',
    '.webm': 'video/webm',
    '.m4v': 'video/mp4',
    '.ogv': 'video/ogg',
    '.mkv': 'video/x-matroska',
    '.bmp': 'image/bmp',
    '.tiff': 'image/tiff',
    '.tif': 'image/tiff',
}


def read_template(name):
    """Read an HTML template and return its contents."""
    path = os.path.join(BASE_DIR, 'templates', name)
    with open(path, 'r') as f:
        return f.read()


# Directories that never hold performance media — skipped by deep search
SEARCH_SKIP_DIRS = {'node_modules', '__pycache__', 'Library', '.Trash',
                    'venv', '.venv', 'env', 'site-packages'}

SEARCH_MAX_RESULTS = 400
SEARCH_MAX_DEPTH = 5
SEARCH_TIME_BUDGET = 6.0  # seconds


def walk_search(base, query):
    """Depth- and time-limited recursive media search under base."""
    import time
    deadline = time.monotonic() + SEARCH_TIME_BUDGET
    results = []
    truncated = False
    timed_out = False

    for root, dirs, files in os.walk(base):
        if time.monotonic() > deadline:
            timed_out = True
            break
        depth = root[len(base):].count(os.sep)
        if depth >= SEARCH_MAX_DEPTH:
            dirs[:] = []
        else:
            dirs[:] = [d for d in dirs
                       if not d.startswith('.') and d not in SEARCH_SKIP_DIRS]
        for fname in files:
            if fname.startswith('.'):
                continue
            ext = os.path.splitext(fname)[1].lower()
            if ext not in ALL_MEDIA or query not in fname.lower():
                continue
            full = os.path.join(root, fname)
            media_type = 'video' if ext in MEDIA_EXTENSIONS['video'] else 'image'
            results.append({
                'name': fname,
                'path': full,
                'rel': os.path.relpath(full, base),
                'type': media_type,
                'ext': ext,
            })
            if len(results) >= SEARCH_MAX_RESULTS:
                truncated = True
                break
        if truncated:
            break

    results.sort(key=lambda r: r['rel'].lower())
    return results, truncated, timed_out


class MixerHandler(BaseHTTPRequestHandler):
    """Handle all Video Mixer HTTP requests."""

    def log_message(self, format, *args):
        """Suppress default request logging."""
        pass

    def send_json(self, data, status=200):
        body = json.dumps(data).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', len(body))
        self.end_headers()
        self.wfile.write(body)

    def send_html(self, html):
        body = html.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', len(body))
        self.end_headers()
        self.wfile.write(body)

    def send_error_json(self, status, message):
        self.send_json({'error': message}, status)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)

        # Routes
        if path == '/':
            self.send_html(read_template('index.html'))
        elif path == '/output':
            self.send_html(read_template('output.html'))
        elif path.startswith('/static/'):
            self.serve_static(path)
        elif path == '/api/browse':
            self.api_browse(params)
        elif path == '/api/search':
            self.api_search(params)
        elif path == '/api/media':
            self.api_media(params)
        elif path == '/api/home':
            self.send_json({'path': str(Path.home())})
        elif path == '/api/stock/status':
            self.send_json(stock_provider.status())
        elif path == '/api/stock/search':
            self.api_stock_search(params)
        elif path == '/api/stock/cache':
            self.send_json(stock_provider.list_cached())
        elif path == '/api/transitions':
            self.api_transitions()
        elif path.startswith('/api/transitions/'):
            name = path.split('/api/transitions/')[-1]
            self.api_serve_transition(name)
        else:
            self.send_error(404, 'Not Found')

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path not in {'/api/stock/cache', '/api/stock/config'}:
            self.send_error(404, 'Not Found')
            return
        if not validate_local_origin(
                self.headers.get('Origin'), self.headers.get('Host'), PORT):
            self.send_json({'error': {
                'code': 'forbidden_origin',
                'message': 'Stock mutations must come from the local mixer.',
            }}, 403)
            return
        content_type = self.headers.get('Content-Type', '').split(';', 1)[0].strip().lower()
        if content_type != 'application/json':
            self.send_json({'error': {
                'code': 'invalid_content_type',
                'message': 'Expected an application/json request body.',
            }}, 415)
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            length = -1
        if length < 0 or length > 4096:
            self.send_json({'error': {
                'code': 'invalid_request_size',
                'message': 'Stock request body is invalid or too large.',
            }}, 413)
            return
        try:
            payload = json.loads(self.rfile.read(length).decode('utf-8'))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self.send_json({'error': {
                'code': 'invalid_json',
                'message': 'Expected a JSON object.',
            }}, 400)
            return
        if not isinstance(payload, dict):
            self.send_json({'error': {
                'code': 'invalid_json',
                'message': 'Expected a JSON object.',
            }}, 400)
            return
        try:
            if parsed.path == '/api/stock/config':
                result = stock_provider.configure(payload.get('apiKey'))
            else:
                result = stock_provider.cache_asset(
                    payload.get('provider'),
                    payload.get('assetId'),
                    payload.get('rendition', 'medium'),
                )
            self.send_json(result)
        except Exception as error:
            self.send_stock_error(error)

    def send_stock_error(self, error):
        if isinstance(error, StockProviderError):
            self.send_json(error.payload(), error.status)
        else:
            self.send_json({'error': {
                'code': 'stock_internal_error',
                'message': 'Stock video request failed.',
            }}, 500)

    def api_stock_search(self, params):
        try:
            self.send_json(stock_provider.search(
                params.get('q', [''])[0],
                params.get('page', [1])[0],
                params.get('order', ['popular'])[0],
            ))
        except Exception as error:
            self.send_stock_error(error)

    def serve_static(self, path):
        """Serve files from the static/ directory."""
        # Remove /static/ prefix and sanitize
        rel_path = path[len('/static/'):]
        full_path = os.path.normpath(os.path.join(BASE_DIR, 'static', rel_path))

        # Security: ensure the path is within static/
        if not full_path.startswith(os.path.join(BASE_DIR, 'static')):
            self.send_error(403, 'Forbidden')
            return

        if not os.path.isfile(full_path):
            self.send_error(404, 'Not Found')
            return

        ext = os.path.splitext(full_path)[1].lower()
        mime = MIME_MAP.get(ext, 'application/octet-stream')

        with open(full_path, 'rb') as f:
            data = f.read()

        self.send_response(200)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', len(data))
        # Local server — always serve fresh JS/CSS so upgrades apply instantly
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        self.wfile.write(data)

    def api_browse(self, params):
        """List directories and media files at a given path."""
        browse_path = params.get('path', [str(Path.home())])[0]
        browse_path = os.path.expanduser(browse_path)

        if not os.path.isdir(browse_path):
            self.send_error_json(400, 'Not a valid directory')
            return

        dirs = []
        files = []

        try:
            entries = sorted(os.listdir(browse_path), key=str.lower)
        except PermissionError:
            self.send_error_json(403, 'Permission denied')
            return

        for entry in entries:
            if entry.startswith('.'):
                continue
            full = os.path.join(browse_path, entry)
            if os.path.isdir(full):
                dirs.append({'name': entry, 'path': full})
            elif os.path.isfile(full):
                ext = os.path.splitext(entry)[1].lower()
                if ext in ALL_MEDIA:
                    media_type = 'video' if ext in MEDIA_EXTENSIONS['video'] else 'image'
                    files.append({
                        'name': entry,
                        'path': full,
                        'type': media_type,
                        'ext': ext,
                    })

        self.send_json({
            'current': browse_path,
            'parent': str(Path(browse_path).parent),
            'dirs': dirs,
            'files': files,
        })

    def api_search(self, params):
        """Recursively search for media files under a path (deep search)."""
        base = params.get('path', [str(Path.home())])[0]
        base = os.path.expanduser(base)
        query = params.get('q', [''])[0].strip().lower()

        if not query:
            self.send_error_json(400, 'Missing search query')
            return
        if not os.path.isdir(base):
            self.send_error_json(400, 'Not a valid directory')
            return

        results, truncated, timed_out = walk_search(base, query)
        self.send_json({
            'query': query,
            'base': base,
            'results': results,
            'truncated': truncated,
            'timedOut': timed_out,
        })

    def api_media(self, params):
        """Serve a media file with range support."""
        file_path = params.get('path', [''])[0]
        if not file_path or not os.path.isfile(file_path):
            self.send_error(404, 'Not Found')
            return

        ext = os.path.splitext(file_path)[1].lower()
        if ext not in ALL_MEDIA:
            self.send_error(403, 'Forbidden')
            return

        mime = MIME_MAP.get(ext)
        if not mime:
            mime = mimetypes.guess_type(file_path)[0] or 'application/octet-stream'

        file_size = os.path.getsize(file_path)

        # Strictly support one RFC-style byte range for video seeking. Invalid,
        # multiple, and unsatisfiable ranges return 416 instead of throwing.
        range_header = self.headers.get('Range')
        if range_header:
            match = re.fullmatch(r'bytes=(\d*)-(\d*)', range_header.strip())
            start = end = None
            if match and file_size > 0 and (match.group(1) or match.group(2)):
                first, last = match.groups()
                if not first:
                    suffix = int(last)
                    if suffix > 0:
                        start = max(0, file_size - suffix)
                        end = file_size - 1
                else:
                    start = int(first)
                    if start < file_size:
                        end = int(last) if last else file_size - 1
                        end = min(end, file_size - 1)
                        if end < start:
                            start = end = None
            if start is None or end is None:
                self.send_response(416)
                self.send_header('Content-Range', f'bytes */{file_size}')
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Content-Length', '0')
                self.end_headers()
                return
            length = end - start + 1

            self.send_response(206)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', length)
            self.send_header('Content-Range', f'bytes {start}-{end}/{file_size}')
            self.send_header('Accept-Ranges', 'bytes')
            self.end_headers()

            with open(file_path, 'rb') as f:
                f.seek(start)
                remaining = length
                try:
                    while remaining > 0:
                        chunk = f.read(min(65536, remaining))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        remaining -= len(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    return
        else:
            self.send_response(200)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', file_size)
            self.send_header('Accept-Ranges', 'bytes')
            self.end_headers()

            with open(file_path, 'rb') as f:
                try:
                    while True:
                        chunk = f.read(65536)
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    return

    def api_transitions(self):
        """List custom transition JS files."""
        if not os.path.isdir(TRANSITIONS_DIR):
            self.send_json({'transitions': []})
            return

        files = glob.glob(os.path.join(TRANSITIONS_DIR, '*.js'))
        transitions = []
        for f in sorted(files):
            name = os.path.splitext(os.path.basename(f))[0]
            transitions.append({'name': name, 'path': f})
        self.send_json({'transitions': transitions})

    def api_serve_transition(self, name):
        """Serve a custom transition JS file."""
        safe_name = os.path.basename(name)
        path = os.path.join(TRANSITIONS_DIR, safe_name + '.js')
        if not os.path.isfile(path):
            self.send_error(404, 'Not Found')
            return

        with open(path, 'rb') as f:
            data = f.read()

        self.send_response(200)
        self.send_header('Content-Type', 'application/javascript')
        self.send_header('Content-Length', len(data))
        self.end_headers()
        self.wfile.write(data)


def main():
    os.makedirs(TRANSITIONS_DIR, exist_ok=True)

    # Threading server: deep searches and media streaming don't block each other
    server = ThreadingHTTPServer(('127.0.0.1', PORT), MixerHandler)

    print()
    print('  ====================================')
    print(f'     VIDEO MIXER v{VERSION} — Web Edition')
    print('  ====================================')
    print(f'  Running at http://127.0.0.1:{PORT}')
    print('  Custom transitions: ~/VideoMixer/transitions/')
    print()
    print('  Press Ctrl+C to quit.')
    print()

    # Open browser after a short delay (skip with --no-browser)
    if '--no-browser' not in sys.argv:
        threading.Timer(1.0, lambda: webbrowser.open(f'http://127.0.0.1:{PORT}')).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\n  Shutting down...')
        server.shutdown()


if __name__ == '__main__':
    main()
