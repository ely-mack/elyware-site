"""Pixabay stock-video search and local caching for Video Mixer.

This module deliberately uses only the Python standard library so both the
Flask/pywebview app and the zero-dependency web server share one implementation.
Remote media URLs are resolved server-side from a numeric Pixabay ID and are
never accepted from the browser.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import threading
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener


PIXABAY_API_URL = "https://pixabay.com/api/videos/"
PIXABAY_LICENSE_URL = "https://pixabay.com/service/terms/"
SEARCH_TTL_SECONDS = 24 * 60 * 60
MAX_JSON_BYTES = 2 * 1024 * 1024
MAX_MEDIA_BYTES = 250 * 1024 * 1024
ALLOWED_RENDITIONS = frozenset({"tiny", "small", "medium"})
ALLOWED_ORDERS = frozenset({"popular", "latest"})
ALLOWED_REMOTE_HOSTS = frozenset({"pixabay.com", "www.pixabay.com", "cdn.pixabay.com"})
API_KEY_RE = re.compile(r"^[A-Za-z0-9_-]{16,128}$")


class StockProviderError(Exception):
    """A safe, structured error suitable for returning to the local UI."""

    def __init__(self, code: str, message: str, status: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status

    def payload(self):
        return {"error": {"code": self.code, "message": self.message}}


def validate_local_origin(origin: str | None, host: str | None, port: int = 5555) -> bool:
    """Reject foreign browser origins/hosts on stock mutation endpoints."""
    allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}", f"[::1]:{port}"}
    if host and host.lower() not in allowed_hosts:
        return False
    if not origin:
        return True
    try:
        parsed = urlparse(origin)
        return (
            parsed.scheme in {"http", "https"}
            and parsed.hostname in {"127.0.0.1", "localhost", "::1"}
            and (parsed.port or (443 if parsed.scheme == "https" else 80)) == port
        )
    except ValueError:
        return False


def _validate_remote_url(url: str) -> str:
    try:
        parsed = urlparse(url)
        port = parsed.port
    except ValueError as exc:
        raise StockProviderError("invalid_provider_response", "Provider returned an invalid media URL", 502) from exc
    if (
        parsed.scheme != "https"
        or parsed.hostname not in ALLOWED_REMOTE_HOSTS
        or port not in {None, 443}
        or parsed.username is not None
        or parsed.password is not None
    ):
        raise StockProviderError("invalid_provider_response", "Provider returned an untrusted media URL", 502)
    return url


class _SafeRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _validate_remote_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class PixabayStockProvider:
    provider = "pixabay"

    def __init__(self, cache_root: str | os.PathLike | None = None, api_key: str | None = None):
        self.cache_root = Path(cache_root or Path.home() / "VideoMixer" / "cache" / "stock")
        self.search_dir = self.cache_root / "search"
        self.media_dir = self.cache_root / "media"
        self.config_path = Path.home() / "VideoMixer" / "config.json"
        self._explicit_key = api_key
        self._lock = threading.RLock()
        self._asset_locks: dict[str, threading.Lock] = {}
        self._opener = build_opener(_SafeRedirectHandler())

    def _api_key(self):
        env_key = os.environ.get("PIXABAY_API_KEY", "").strip()
        if API_KEY_RE.fullmatch(env_key):
            return env_key, "env"
        if self._explicit_key and API_KEY_RE.fullmatch(self._explicit_key):
            return self._explicit_key, "config"
        try:
            data = json.loads(self.config_path.read_text(encoding="utf-8"))
            key = data.get("pixabayApiKey", "").strip()
            if API_KEY_RE.fullmatch(key):
                return key, "config"
        except (OSError, ValueError, TypeError, AttributeError):
            pass
        return "", None

    def _require_key(self) -> str:
        key, _ = self._api_key()
        if not key:
            raise StockProviderError(
                "provider_unconfigured",
                "Pixabay is not configured. Add an API key in Stock settings.",
                503,
            )
        return key

    def configure(self, api_key: object):
        if not isinstance(api_key, str) or not API_KEY_RE.fullmatch(api_key.strip()):
            raise StockProviderError(
                "invalid_api_key",
                "Pixabay API key must be 16–128 letters, numbers, underscores, or hyphens.",
                400,
            )
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.config_path.with_name(f".{self.config_path.name}.{os.getpid()}.tmp")
        try:
            existing = json.loads(self.config_path.read_text(encoding="utf-8"))
            if not isinstance(existing, dict):
                existing = {}
        except (OSError, ValueError, TypeError):
            existing = {}
        existing["pixabayApiKey"] = api_key.strip()
        try:
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(existing, handle)
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(tmp, 0o600)
            os.replace(tmp, self.config_path)
            os.chmod(self.config_path, 0o600)
        finally:
            try:
                tmp.unlink()
            except FileNotFoundError:
                pass
        # Tests and embedded callers may have supplied an explicit key; a saved
        # UI key should become active unless the environment overrides it.
        self._explicit_key = api_key.strip()
        return self.status()

    def status(self):
        key, source = self._api_key()
        count = 0
        total_bytes = 0
        try:
            for path in self.media_dir.glob("pixabay-*-*.mp4"):
                if path.is_file():
                    count += 1
                    total_bytes += path.stat().st_size
        except OSError:
            pass
        return {
            "provider": self.provider,
            "configured": bool(key),
            "keySource": source,
            "cacheCount": count,
            "cacheBytes": total_bytes,
        }

    @staticmethod
    def _asset_id(value: object) -> int:
        if isinstance(value, bool):
            raise StockProviderError("invalid_asset_id", "Asset ID must be numeric", 400)
        text = str(value).strip()
        if not text.isdigit():
            raise StockProviderError("invalid_asset_id", "Asset ID must be numeric", 400)
        asset_id = int(text)
        if asset_id <= 0 or asset_id > 9_223_372_036_854_775_807:
            raise StockProviderError("invalid_asset_id", "Asset ID is out of range", 400)
        return asset_id

    @staticmethod
    def _rendition(value: object) -> str:
        rendition = str(value or "medium").strip().lower()
        if rendition not in ALLOWED_RENDITIONS:
            raise StockProviderError("invalid_rendition", "Rendition must be tiny, small, or medium", 400)
        return rendition

    def _cache_key(self, params: dict[str, object]) -> str:
        canonical = json.dumps(params, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def _read_query_cache(self, path: Path):
        try:
            if time.time() - path.stat().st_mtime >= SEARCH_TTL_SECONDS:
                return None
            payload = json.loads(path.read_text(encoding="utf-8"))
            return payload if isinstance(payload, dict) else None
        except (OSError, ValueError, TypeError):
            return None

    @staticmethod
    def _write_json_atomic(path: Path, payload: dict):
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
        try:
            with open(tmp, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, separators=(",", ":"))
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp, path)
        finally:
            try:
                tmp.unlink()
            except FileNotFoundError:
                pass

    def _provider_json(self, params: dict[str, object]):
        cache_path = self.search_dir / f"{self._cache_key(params)}.json"
        with self._lock:
            cached = self._read_query_cache(cache_path)
        if cached is not None:
            return cached

        query = {"key": self._require_key(), **params}
        url = f"{PIXABAY_API_URL}?{urlencode(query)}"
        request = Request(url, headers={"Accept": "application/json", "User-Agent": "VideoMixer/4"})
        try:
            with self._opener.open(request, timeout=10) as response:
                body = response.read(MAX_JSON_BYTES + 1)
        except HTTPError as exc:
            if exc.code == 429:
                raise StockProviderError("provider_rate_limited", "Pixabay rate limit reached. Try again shortly.", 429) from None
            if exc.code in {401, 403}:
                raise StockProviderError("provider_auth_failed", "Pixabay rejected the configured API key.", 502) from None
            raise StockProviderError("provider_http_error", "Pixabay search is temporarily unavailable.", 502) from None
        except (URLError, TimeoutError, OSError):
            raise StockProviderError("provider_unavailable", "Could not reach Pixabay.", 503) from None
        if len(body) > MAX_JSON_BYTES:
            raise StockProviderError("provider_response_too_large", "Pixabay returned an oversized response.", 502)
        try:
            payload = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise StockProviderError("invalid_provider_response", "Pixabay returned invalid data.", 502) from None
        if not isinstance(payload, dict) or not isinstance(payload.get("hits", []), list):
            raise StockProviderError("invalid_provider_response", "Pixabay returned unexpected data.", 502)
        with self._lock:
            self._write_json_atomic(cache_path, payload)
        return payload

    def search(self, query: object = "", page: object = 1, order: object = "popular"):
        query = str(query or "").strip()
        if len(query) > 100:
            raise StockProviderError("invalid_query", "Search query cannot exceed 100 characters", 400)
        try:
            page = int(page)
        except (TypeError, ValueError):
            raise StockProviderError("invalid_page", "Page must be a positive integer", 400) from None
        # Pixabay exposes at most 500 hits per query; 24 results per page means
        # page 21 is the final useful page.
        if page < 1 or page > 21:
            raise StockProviderError("invalid_page", "Page must be between 1 and 21", 400)
        order = str(order or "popular").lower()
        if order not in ALLOWED_ORDERS:
            raise StockProviderError("invalid_order", "Order must be popular or latest", 400)
        params = {
            "q": query,
            "page": page,
            "order": order,
            "per_page": 24,
            "video_type": "all",
            "safesearch": "true",
            "min_width": 1280,
            "min_height": 720,
        }
        payload = self._provider_json(params)
        results = []
        for hit in payload.get("hits", []):
            if not isinstance(hit, dict):
                continue
            try:
                asset_id = self._asset_id(hit.get("id"))
            except StockProviderError:
                continue
            videos = hit.get("videos") if isinstance(hit.get("videos"), dict) else {}
            medium = videos.get("medium") if isinstance(videos.get("medium"), dict) else {}
            tags = [tag.strip() for tag in str(hit.get("tags", "")).split(",") if tag.strip()]
            creator_name = str(hit.get("user") or "Pixabay creator")
            creator_id = int(hit.get("user_id") or 0)
            creator_url = (
                f"https://pixabay.com/users/{quote(creator_name, safe='')}-{creator_id}/"
                if creator_id else str(hit.get("pageURL") or "")
            )
            results.append({
                "id": asset_id,
                "name": tags[0].title() if tags else f"Pixabay Video {asset_id}",
                "tags": tags,
                "duration": int(hit.get("duration") or 0),
                "width": int(medium.get("width") or 0),
                "height": int(medium.get("height") or 0),
                "thumbnailUrl": str(medium.get("thumbnail") or ""),
                "pageUrl": str(hit.get("pageURL") or ""),
                "creator": {"name": creator_name, "url": creator_url},
                "cached": self._media_path(asset_id, "medium").is_file(),
            })
        return {
            "provider": self.provider,
            "query": query,
            "page": page,
            "perPage": 24,
            "total": int(payload.get("totalHits") or payload.get("total") or 0),
            "results": results,
        }

    def _media_path(self, asset_id: int, rendition: str) -> Path:
        return self.media_dir / f"pixabay-{asset_id}-{rendition}.mp4"

    def _metadata_path(self, asset_id: int, rendition: str) -> Path:
        return self.media_dir / f"pixabay-{asset_id}-{rendition}.json"

    def _playlist_item(self, hit: dict, asset_id: int, rendition: str, path: Path):
        videos = hit.get("videos") if isinstance(hit.get("videos"), dict) else {}
        version = videos.get(rendition) if isinstance(videos.get(rendition), dict) else {}
        tags = [tag.strip() for tag in str(hit.get("tags", "")).split(",") if tag.strip()]
        creator_name = str(hit.get("user") or "Pixabay creator")
        creator_id = int(hit.get("user_id") or 0)
        creator = {
            "name": creator_name,
            "url": (
                f"https://pixabay.com/users/{quote(creator_name, safe='')}-{creator_id}/"
                if creator_id else str(hit.get("pageURL") or "")
            ),
        }
        return {
            "name": tags[0].title() if tags else f"Pixabay Video {asset_id}",
            "type": "video",
            "path": str(path.resolve()),
            "source": "stock",
            "provider": self.provider,
            "assetId": asset_id,
            "rendition": rendition,
            "duration": int(hit.get("duration") or 0),
            "width": int(version.get("width") or 0),
            "height": int(version.get("height") or 0),
            "tags": tags,
            "pageUrl": str(hit.get("pageURL") or ""),
            "creator": creator,
            "license": {"name": "Pixabay Content License", "url": PIXABAY_LICENSE_URL},
        }

    def _asset_hit(self, asset_id: int):
        payload = self._provider_json({"id": asset_id})
        for hit in payload.get("hits", []):
            if isinstance(hit, dict) and str(hit.get("id")) == str(asset_id):
                return hit
        raise StockProviderError("asset_not_found", "Pixabay video was not found", 404)

    def cache_asset(self, provider: object, asset_id: object, rendition: object = "medium"):
        if str(provider or "").lower() != self.provider:
            raise StockProviderError("invalid_provider", "Only Pixabay is supported", 400)
        asset_id = self._asset_id(asset_id)
        rendition = self._rendition(rendition)
        media_path = self._media_path(asset_id, rendition)
        metadata_path = self._metadata_path(asset_id, rendition)
        lock_key = f"{asset_id}:{rendition}"
        with self._lock:
            asset_lock = self._asset_locks.setdefault(lock_key, threading.Lock())
        with asset_lock:
            if media_path.is_file() and media_path.stat().st_size > 0 and metadata_path.is_file():
                try:
                    item = json.loads(metadata_path.read_text(encoding="utf-8"))
                    if isinstance(item, dict):
                        item["path"] = str(media_path.resolve())
                        return {"cached": True, "item": item}
                except (OSError, ValueError):
                    pass

            hit = self._asset_hit(asset_id)
            videos = hit.get("videos") if isinstance(hit.get("videos"), dict) else {}
            version = videos.get(rendition) if isinstance(videos.get(rendition), dict) else None
            if not version or not version.get("url"):
                raise StockProviderError("rendition_unavailable", "Requested video rendition is unavailable", 404)
            size = int(version.get("size") or 0)
            if size > MAX_MEDIA_BYTES:
                raise StockProviderError("asset_too_large", "Video exceeds the 250 MB cache limit", 413)
            media_url = _validate_remote_url(str(version["url"]))
            media_path.parent.mkdir(parents=True, exist_ok=True)
            part = media_path.with_name(f".{media_path.name}.{os.getpid()}.{threading.get_ident()}.part")
            request = Request(media_url, headers={"Accept": "video/mp4,video/*", "User-Agent": "VideoMixer/4"})
            total = 0
            try:
                with self._opener.open(request, timeout=60) as response, open(part, "wb") as handle:
                    _validate_remote_url(response.geturl())
                    content_type = response.headers.get_content_type()
                    if not (content_type.startswith("video/") or content_type == "application/octet-stream"):
                        raise StockProviderError("invalid_media_type", "Pixabay returned a non-video response", 502)
                    content_length = response.headers.get("Content-Length")
                    if content_length and int(content_length) > MAX_MEDIA_BYTES:
                        raise StockProviderError("asset_too_large", "Video exceeds the 250 MB cache limit", 413)
                    while True:
                        chunk = response.read(64 * 1024)
                        if not chunk:
                            break
                        total += len(chunk)
                        if total > MAX_MEDIA_BYTES:
                            raise StockProviderError("asset_too_large", "Video exceeds the 250 MB cache limit", 413)
                        handle.write(chunk)
                    handle.flush()
                    os.fsync(handle.fileno())
                if total == 0:
                    raise StockProviderError("empty_media", "Pixabay returned an empty video", 502)
                os.replace(part, media_path)
            except StockProviderError:
                raise
            except HTTPError as exc:
                raise StockProviderError("media_download_failed", f"Pixabay video download failed ({exc.code})", 502) from None
            except (URLError, TimeoutError, OSError, ValueError):
                raise StockProviderError("media_download_failed", "Could not download the Pixabay video", 503) from None
            finally:
                try:
                    part.unlink()
                except FileNotFoundError:
                    pass

            item = self._playlist_item(hit, asset_id, rendition, media_path)
            self._write_json_atomic(metadata_path, item)
            return {"cached": True, "item": item}

    def list_cached(self):
        items = []
        try:
            metadata_files = sorted(self.media_dir.glob("pixabay-*-*.json"))
        except OSError:
            metadata_files = []
        for metadata_path in metadata_files:
            try:
                item = json.loads(metadata_path.read_text(encoding="utf-8"))
                if not isinstance(item, dict):
                    continue
                asset_id = self._asset_id(item.get("assetId"))
                rendition = self._rendition(item.get("rendition"))
                media_path = self._media_path(asset_id, rendition)
                if not media_path.is_file() or media_path.stat().st_size <= 0:
                    continue
                item["path"] = str(media_path.resolve())
                items.append(item)
            except (OSError, ValueError, TypeError, StockProviderError):
                continue
        return {"items": items}


stock_provider = PixabayStockProvider()
