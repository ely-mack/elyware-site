#!/bin/bash
# Stock Bridge for Resolume
# Double-click to launch. Works on any Mac with Python 3.
# Searches Pixabay and sends clips into Resolume Arena/Avenue
# via the Resolume REST API (Preferences > Webserver).

cd "$(dirname "$0")"

echo ""
echo "  =========================================="
echo "     STOCK BRIDGE FOR RESOLUME"
echo "  =========================================="
echo ""

# Check for Python 3
if ! command -v python3 &>/dev/null; then
    echo "  Python 3 not found. Please install it from:"
    echo "  https://www.python.org/downloads/"
    echo ""
    read -p "  Press Enter to open the download page..."
    open "https://www.python.org/downloads/"
    exit 1
fi

echo "  Python: $(python3 --version)"
echo "  Starting Stock Bridge..."
echo ""

python3 resolume_bridge.py
