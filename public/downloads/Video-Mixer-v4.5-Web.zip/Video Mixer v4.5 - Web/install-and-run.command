#!/bin/bash
# Video Mixer — One-click installer & launcher for any Mac
# Double-click this file to install dependencies and launch.

set -e
cd "$(dirname "$0")"

echo ""
echo "  🎬 Video Mixer — Installing..."
echo ""

# Check for Python 3
if ! command -v python3 &>/dev/null; then
    echo "  Python 3 not found. Please install it from https://www.python.org/downloads/"
    echo "  Then double-click this file again."
    echo ""
    read -p "  Press Enter to open the download page..."
    open "https://www.python.org/downloads/"
    exit 1
fi

echo "  Python: $(python3 --version)"

# Install Flask only (no pywebview — avoids needing Xcode tools)
echo "  Installing Flask..."
python3 -m pip install --user flask 2>&1 | tail -3

echo ""
echo "  🎬 Launching Video Mixer in browser..."
echo "  (Output window: click 'Output Window' button, drag to second monitor)"
echo ""

# Launch in browser mode (no pywebview needed)
python3 video_mixer.py --browser
