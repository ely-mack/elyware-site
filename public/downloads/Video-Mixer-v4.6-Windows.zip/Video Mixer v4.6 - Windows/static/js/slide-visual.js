/**
 * Message slide + geometric background renderer — Video Mixer v4.5
 *
 * This file intentionally has no mixer dependencies. The same plain-data
 * config is rendered in the composer, either deck, recordings, Screenfolk,
 * pad thumbnails, and the independent output window.
 */

(function (root) {
    'use strict';

    const SLIDE_VISUAL_ID = 'message-slide';
    const SLIDE_LOOP_SECONDS = 10;
    const SLIDE_MAX_TEXT = 280;
    const SLIDE_PATTERNS = Object.freeze([
        'solid', 'color-field', 'hard-split', 'bars', 'checker', 'grid',
        'dots', 'rings', 'polygons', 'corners', 'frames', 'diagonal',
    ]);
    const SLIDE_FONTS = Object.freeze(['sans', 'serif', 'mono']);
    const SLIDE_ALIGNS = Object.freeze(['left', 'center', 'right']);
    const SLIDE_VALIGNS = Object.freeze(['top', 'center', 'bottom']);

    const DEFAULT_SLIDE_CONFIG = Object.freeze({
        version: 1,
        text: 'YOUR MESSAGE',
        pattern: 'solid',
        bgColor: '#101326',
        accentColor: '#7C5CFF',
        textColor: '#FFFFFF',
        fontFamily: 'sans',
        fontSize: 14,
        fontWeight: 900,
        align: 'center',
        valign: 'center',
        motionSpeed: 1,
        hue: 0,
        hueCycle: false,
        invert: false,
        strobe: false,
        strobeRate: 1,
        seed: 1,
    });

    const FONT_STACKS = {
        sans: '-apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif',
        serif: 'Georgia, "Times New Roman", serif',
        mono: '"SF Mono", Menlo, Consolas, monospace',
    };
    const GRAPHEME_SEGMENTER = root.Intl && typeof root.Intl.Segmenter === 'function'
        ? new root.Intl.Segmenter(undefined, { granularity: 'grapheme' })
        : null;

    function splitGraphemes(value) {
        const text = String(value == null ? '' : value);
        if (!GRAPHEME_SEGMENTER) return Array.from(text);
        return Array.from(GRAPHEME_SEGMENTER.segment(text), part => part.segment);
    }

    function truncateSlideText(value) {
        return splitGraphemes(String(value == null ? '' : value).replace(/\r\n?/g, '\n'))
            .slice(0, SLIDE_MAX_TEXT)
            .join('');
    }

    function countSlideText(value) {
        return splitGraphemes(value).length;
    }

    function clamp(value, min, max, fallback) {
        const number = Number(value);
        if (!Number.isFinite(number)) return fallback;
        return Math.max(min, Math.min(max, number));
    }

    function bool(value, fallback = false) {
        return typeof value === 'boolean' ? value : fallback;
    }

    function normalizeHex(value, fallback) {
        const color = String(value || '').trim();
        if (/^#[0-9a-f]{6}$/i.test(color)) return color.toUpperCase();
        if (/^#[0-9a-f]{3}$/i.test(color)) {
            return `#${color.slice(1).split('').map(char => char + char).join('')}`.toUpperCase();
        }
        return fallback;
    }

    function normalizeSlideConfig(input) {
        const source = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
        const pattern = SLIDE_PATTERNS.includes(source.pattern) ? source.pattern : DEFAULT_SLIDE_CONFIG.pattern;
        const fontFamily = SLIDE_FONTS.includes(source.fontFamily) ? source.fontFamily : DEFAULT_SLIDE_CONFIG.fontFamily;
        const align = SLIDE_ALIGNS.includes(source.align) ? source.align : DEFAULT_SLIDE_CONFIG.align;
        const valign = SLIDE_VALIGNS.includes(source.valign) ? source.valign : DEFAULT_SLIDE_CONFIG.valign;
        const weightValue = Math.round(clamp(source.fontWeight, 400, 900, DEFAULT_SLIDE_CONFIG.fontWeight));
        const fontWeight = weightValue >= 800 ? 900 : weightValue >= 550 ? 700 : 400;
        const rawRate = clamp(source.strobeRate, 0.5, 3, DEFAULT_SLIDE_CONFIG.strobeRate);

        return {
            version: 1,
            text: truncateSlideText(source.text == null ? DEFAULT_SLIDE_CONFIG.text : source.text),
            pattern,
            bgColor: normalizeHex(source.bgColor, DEFAULT_SLIDE_CONFIG.bgColor),
            accentColor: normalizeHex(source.accentColor, DEFAULT_SLIDE_CONFIG.accentColor),
            textColor: normalizeHex(source.textColor, DEFAULT_SLIDE_CONFIG.textColor),
            fontFamily,
            fontSize: Math.round(clamp(source.fontSize, 6, 28, DEFAULT_SLIDE_CONFIG.fontSize)),
            fontWeight,
            align,
            valign,
            motionSpeed: Math.round(clamp(source.motionSpeed, 0, 2, DEFAULT_SLIDE_CONFIG.motionSpeed) * 4) / 4,
            hue: Math.round(clamp(source.hue, 0, 360, DEFAULT_SLIDE_CONFIG.hue)),
            hueCycle: bool(source.hueCycle, DEFAULT_SLIDE_CONFIG.hueCycle),
            invert: bool(source.invert, DEFAULT_SLIDE_CONFIG.invert),
            strobe: bool(source.strobe, DEFAULT_SLIDE_CONFIG.strobe),
            // Half-Hz steps make the optional flash repeat exactly on the shared 10s loop.
            strobeRate: Math.round(rawRate * 2) / 2,
            seed: Math.floor(clamp(source.seed, 0, 0xffffffff, DEFAULT_SLIDE_CONFIG.seed)) >>> 0,
        };
    }

    function snapshotSlideConfig(input) {
        return { ...normalizeSlideConfig(input) };
    }

    function phaseAt(time, speed = 1) {
        const scaled = (Number(time) || 0) * (Number(speed) || 0);
        return ((scaled % SLIDE_LOOP_SECONDS) + SLIDE_LOOP_SECONDS) % SLIDE_LOOP_SECONDS / SLIDE_LOOP_SECONDS;
    }

    function hexRgb(hex) {
        const value = normalizeHex(hex, '#000000');
        return [
            parseInt(value.slice(1, 3), 16),
            parseInt(value.slice(3, 5), 16),
            parseInt(value.slice(5, 7), 16),
        ];
    }

    function mixColor(from, to, amount) {
        const a = hexRgb(from);
        const b = hexRgb(to);
        const t = Math.max(0, Math.min(1, amount));
        return `rgb(${a.map((value, index) => Math.round(value + (b[index] - value) * t)).join(',')})`;
    }

    function invertHex(color) {
        const inverted = hexRgb(color).map(value => 255 - value);
        return `#${inverted.map(value => value.toString(16).padStart(2, '0')).join('')}`.toUpperCase();
    }

    function isStrobeFlash(config, time) {
        return config.strobe
            && Math.floor((((Number(time) || 0) * config.strobeRate) % 1 + 1) % 1 * 2) === 0;
    }

    function drawPolygon(ctx, cx, cy, radius, sides, rotation) {
        ctx.beginPath();
        for (let index = 0; index < sides; index++) {
            const angle = rotation + index * Math.PI * 2 / sides;
            const x = cx + Math.cos(angle) * radius;
            const y = cy + Math.sin(angle) * radius;
            if (index === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        }
        ctx.closePath();
    }

    function drawSlideBackground(ctx, configInput, time, width, height) {
        const config = normalizeSlideConfig(configInput);
        const w = Math.max(1, Number(width) || 1);
        const h = Math.max(1, Number(height) || 1);
        const phase = phaseAt(time, config.motionSpeed);
        const huePhase = phaseAt(time, 1);
        const tau = Math.PI * 2;
        const pulse = 0.5 - 0.5 * Math.cos(tau * phase);
        const flash = isStrobeFlash(config, time);
        const inverted = Boolean(config.invert) !== Boolean(flash);
        const hue = (config.hue + (config.hueCycle ? huePhase * 360 : 0)) % 360;

        ctx.save();
        ctx.filter = hue || inverted
            ? `hue-rotate(${hue}deg)${inverted ? ' invert(1)' : ''}`
            : 'none';
        // Every frame begins with an opaque full-canvas paint. This prevents a
        // transparent/black cue frame in previews and program output.
        ctx.fillStyle = config.bgColor;
        ctx.fillRect(0, 0, w, h);

        switch (config.pattern) {
            case 'color-field': {
                ctx.fillStyle = mixColor(config.bgColor, config.accentColor, pulse);
                ctx.fillRect(0, 0, w, h);
                break;
            }
            case 'hard-split': {
                const split = w * (0.5 + Math.sin(tau * phase) * 0.18);
                ctx.fillStyle = config.accentColor;
                ctx.fillRect(split, 0, w - split, h);
                ctx.fillStyle = config.textColor;
                ctx.fillRect(split - Math.max(2, w * 0.006), 0, Math.max(4, w * 0.012), h);
                break;
            }
            case 'bars': {
                const bar = w / 8;
                const offset = phase * bar * 2;
                ctx.fillStyle = config.accentColor;
                for (let index = -2; index < 10; index += 2) {
                    ctx.fillRect(index * bar + offset, 0, bar, h);
                }
                break;
            }
            case 'checker': {
                const cols = 8;
                const rows = 5;
                const cw = w / cols;
                const ch = h / rows;
                for (let row = 0; row < rows; row++) {
                    const offset = (row % 2 ? 1 : -1) * phase * cw * 2;
                    for (let col = -2; col < cols + 2; col++) {
                        if ((row + col) % 2) continue;
                        ctx.fillStyle = config.accentColor;
                        ctx.fillRect(col * cw + offset, row * ch, cw + 1, ch + 1);
                    }
                }
                break;
            }
            case 'grid': {
                const dx = w / 10;
                const dy = h / 6;
                const ox = phase * dx;
                const oy = phase * dy;
                ctx.strokeStyle = config.accentColor;
                ctx.lineWidth = Math.max(1, h * 0.005);
                ctx.beginPath();
                for (let x = -dx + ox; x <= w + dx; x += dx) { ctx.moveTo(x, 0); ctx.lineTo(x, h); }
                for (let y = -dy + oy; y <= h + dy; y += dy) { ctx.moveTo(0, y); ctx.lineTo(w, y); }
                ctx.stroke();
                break;
            }
            case 'dots': {
                const cols = 12;
                const rows = 7;
                const cw = w / cols;
                const ch = h / rows;
                ctx.fillStyle = config.accentColor;
                for (let row = 0; row < rows; row++) {
                    for (let col = 0; col < cols; col++) {
                        const wave = 0.5 + 0.5 * Math.sin(tau * phase + col * 0.55 + row * 0.7);
                        const radius = Math.min(cw, ch) * (0.1 + wave * 0.24);
                        ctx.beginPath();
                        ctx.arc((col + 0.5) * cw, (row + 0.5) * ch, radius, 0, tau);
                        ctx.fill();
                    }
                }
                break;
            }
            case 'rings': {
                const spacing = h * 0.09;
                const travel = phase * spacing;
                ctx.strokeStyle = config.accentColor;
                ctx.lineWidth = Math.max(2, h * 0.009);
                ctx.beginPath();
                for (let index = 0; index < 14; index++) {
                    const radius = travel + index * spacing;
                    ctx.moveTo(w / 2 + radius, h / 2);
                    ctx.arc(w / 2, h / 2, radius, 0, tau);
                }
                ctx.stroke();
                break;
            }
            case 'polygons': {
                const radius = h * (0.2 + pulse * 0.04);
                ctx.lineWidth = Math.max(2, h * 0.01);
                [[3, 1.55, 1], [4, 1.05, -1], [6, 0.6, 2]].forEach((shape, index) => {
                    drawPolygon(ctx, w / 2, h / 2, radius * shape[1], shape[0], tau * phase * shape[2] - Math.PI / 2);
                    ctx.strokeStyle = index === 1 ? config.textColor : config.accentColor;
                    ctx.stroke();
                });
                break;
            }
            case 'corners': {
                const bw = w * (0.2 + pulse * 0.08);
                const bh = h * (0.24 + pulse * 0.08);
                ctx.fillStyle = config.accentColor;
                ctx.fillRect(0, 0, bw, bh);
                ctx.fillRect(w - bw, 0, bw, bh);
                ctx.fillRect(0, h - bh, bw, bh);
                ctx.fillRect(w - bw, h - bh, bw, bh);
                break;
            }
            case 'frames': {
                ctx.lineWidth = Math.max(2, h * 0.008);
                for (let index = 0; index < 6; index++) {
                    const scale = 0.12 + index * 0.145 + pulse * 0.018 * (index + 1);
                    const fw = w * scale;
                    const fh = h * scale;
                    ctx.strokeStyle = index % 2 ? config.accentColor : config.textColor;
                    ctx.strokeRect((w - fw) / 2, (h - fh) / 2, fw, fh);
                }
                break;
            }
            case 'diagonal': {
                const spacing = h * 0.12;
                const offset = phase * spacing;
                ctx.strokeStyle = config.accentColor;
                ctx.lineWidth = Math.max(3, h * 0.025);
                ctx.beginPath();
                for (let pos = -w - h + offset; pos < w + h; pos += spacing) {
                    ctx.moveTo(pos, h);
                    ctx.lineTo(pos + h, 0);
                }
                ctx.stroke();
                break;
            }
            case 'solid':
            default:
                break;
        }
        ctx.restore();
    }

    function splitLongToken(ctx, token, maxWidth) {
        const parts = [];
        let part = '';
        for (const char of splitGraphemes(token)) {
            const candidate = part + char;
            if (part && ctx.measureText(candidate).width > maxWidth) {
                parts.push(part);
                part = char;
            } else {
                part = candidate;
            }
        }
        if (part || parts.length === 0) parts.push(part);
        return parts;
    }

    function wrapSlideText(ctx, text, maxWidth) {
        const lines = [];
        const paragraphs = String(text == null ? '' : text).split('\n');
        paragraphs.forEach(paragraph => {
            if (paragraph === '') {
                lines.push('');
                return;
            }
            const words = paragraph.trim().split(/\s+/);
            let line = '';
            words.forEach(word => {
                const chunks = ctx.measureText(word).width > maxWidth
                    ? splitLongToken(ctx, word, maxWidth)
                    : [word];
                chunks.forEach(chunk => {
                    const candidate = line ? `${line} ${chunk}` : chunk;
                    if (line && ctx.measureText(candidate).width > maxWidth) {
                        lines.push(line);
                        line = chunk;
                    } else {
                        line = candidate;
                    }
                });
            });
            lines.push(line);
        });
        return lines;
    }

    function ellipsize(ctx, line, maxWidth) {
        const chars = splitGraphemes(line);
        while (chars.length && ctx.measureText(`${chars.join('')}…`).width > maxWidth) chars.pop();
        return `${chars.join('')}…`;
    }

    function textLayout(ctx, config, width, height) {
        const maxWidth = width * 0.82;
        const maxHeight = height * 0.76;
        const minSize = Math.max(12, height * 0.045);
        let size = Math.max(minSize, height * config.fontSize / 100);
        let lines = [];
        let lineHeight = size * 1.14;
        const stack = FONT_STACKS[config.fontFamily] || FONT_STACKS.sans;

        while (size >= minSize) {
            ctx.font = `${config.fontWeight} ${size}px ${stack}`;
            lines = wrapSlideText(ctx, config.text, maxWidth);
            lineHeight = size * 1.14;
            if (lines.length * lineHeight <= maxHeight) break;
            size -= Math.max(1, height * 0.004);
        }

        const maxLines = Math.max(1, Math.floor(maxHeight / lineHeight));
        if (lines.length > maxLines) {
            lines = lines.slice(0, maxLines);
            lines[maxLines - 1] = ellipsize(ctx, lines[maxLines - 1], maxWidth);
        }
        return { lines, lineHeight, size, maxWidth };
    }

    function drawSlideText(ctx, configInput, width, height) {
        const config = normalizeSlideConfig(configInput);
        if (!config.text) return;
        const w = Math.max(1, Number(width) || 1);
        const h = Math.max(1, Number(height) || 1);

        ctx.save();
        const layout = textLayout(ctx, config, w, h);
        ctx.fillStyle = config.textColor;
        ctx.textAlign = config.align;
        ctx.textBaseline = 'middle';
        ctx.shadowColor = 'rgba(0,0,0,0.62)';
        ctx.shadowBlur = Math.max(2, layout.size * 0.12);
        ctx.shadowOffsetY = Math.max(1, layout.size * 0.045);

        const totalHeight = layout.lines.length * layout.lineHeight;
        let y;
        if (config.valign === 'top') y = h * 0.12 + layout.lineHeight / 2;
        else if (config.valign === 'bottom') y = h * 0.88 - totalHeight + layout.lineHeight / 2;
        else y = (h - totalHeight) / 2 + layout.lineHeight / 2;

        const x = config.align === 'left' ? w * 0.09 : config.align === 'right' ? w * 0.91 : w / 2;
        layout.lines.forEach((line, index) => ctx.fillText(line, x, y + index * layout.lineHeight, layout.maxWidth));
        ctx.restore();
    }

    function renderSlideFrame(ctx, configInput, time, width, height) {
        const config = normalizeSlideConfig(configInput);
        drawSlideBackground(ctx, config, time, width, height);
        const inverted = Boolean(config.invert) !== Boolean(isStrobeFlash(config, time));
        drawSlideText(ctx, inverted ? { ...config, textColor: invertHex(config.textColor) } : config, width, height);
        return config;
    }

    function createSlideVisualInstance(configInput, width = 1280, height = 720) {
        if (!root.document || typeof root.document.createElement !== 'function') return null;
        const config = normalizeSlideConfig(configInput);
        const canvas = root.document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(Number(width) || 1280));
        canvas.height = Math.max(1, Math.round(Number(height) || 720));
        const ctx = canvas.getContext('2d');
        if (!ctx) return null;

        const instance = {
            id: SLIDE_VISUAL_ID,
            name: 'Message Slide',
            canvas,
            config,
            _t: 0,
            _last: null,
            tick(now, speed = 1) {
                if (this._last === null) this._last = now;
                const dt = Math.min(Math.max(0, (now - this._last) / 1000), 0.1) * (Number(speed) || 0);
                this._last = now;
                this._t += dt;
                renderSlideFrame(ctx, this.config, this._t, canvas.width, canvas.height);
            },
            renderAt(time) {
                this._t = Math.max(0, Number(time) || 0);
                renderSlideFrame(ctx, this.config, this._t, canvas.width, canvas.height);
            },
        };
        // Paint synchronously so cueing a paused slide never exposes a blank frame.
        instance.renderAt(0);
        return instance;
    }

    function slideName(configInput) {
        const config = normalizeSlideConfig(configInput);
        const firstLine = config.text.split('\n').map(line => line.trim()).find(Boolean) || 'Pattern';
        return `Slide — ${splitGraphemes(firstLine).slice(0, 42).join('')}`;
    }

    const api = {
        SLIDE_VISUAL_ID,
        SLIDE_LOOP_SECONDS,
        SLIDE_MAX_TEXT,
        SLIDE_PATTERNS,
        DEFAULT_SLIDE_CONFIG,
        splitGraphemes,
        truncateSlideText,
        countSlideText,
        normalizeSlideConfig,
        snapshotSlideConfig,
        phaseAt,
        wrapSlideText,
        renderSlideFrame,
        createSlideVisualInstance,
        slideName,
    };

    Object.assign(root, api);
    if (typeof module !== 'undefined' && module.exports) module.exports = api;
}(typeof window !== 'undefined' ? window : globalThis));
