/** Create-a-slide dialog controller — Video Mixer v4.5 */

(function (root) {
    'use strict';

    const PATTERN_LABELS = {
        solid: 'Solid',
        'color-field': 'Color',
        'hard-split': 'Split',
        bars: 'Bars',
        checker: 'Checker',
        grid: 'Grid',
        dots: 'Dots',
        rings: 'Rings',
        polygons: 'Polygons',
        corners: 'Corners',
        frames: 'Frames',
        diagonal: 'Diagonal',
    };

    function setupSlideComposer(options = {}) {
        const trigger = document.getElementById('create-slide-btn');
        const overlay = document.getElementById('slide-composer-overlay');
        const form = document.getElementById('slide-composer-form');
        const canvas = document.getElementById('slide-composer-preview');
        if (!trigger || !overlay || !form || !canvas || typeof root.renderSlideFrame !== 'function') return;

        const ctx = canvas.getContext('2d');
        const message = document.getElementById('slide-message');
        const charCount = document.getElementById('slide-char-count');
        const patternGrid = document.getElementById('slide-pattern-grid');
        const hueValue = document.getElementById('slide-hue-value');
        const motionValue = document.getElementById('slide-motion-value');
        const strobeValue = document.getElementById('slide-strobe-value');
        const strobeWarning = document.getElementById('slide-strobe-warning');
        const queueButton = document.getElementById('slide-queue-btn');
        const playButton = document.getElementById('slide-play-btn');
        let selectedPattern = root.DEFAULT_SLIDE_CONFIG.pattern;
        let animationFrame = 0;
        let openedAt = 0;
        let restoreFocus = null;
        let composerSeed = 1;

        function getField(id) {
            return document.getElementById(id);
        }

        function targetDeckId() {
            const selected = form.querySelector('input[name="slide-target"]:checked');
            return selected && selected.value === 'b' ? 'b' : 'a';
        }

        function readConfig() {
            return root.normalizeSlideConfig({
                text: message.value,
                pattern: selectedPattern,
                bgColor: getField('slide-bg-color').value,
                accentColor: getField('slide-accent-color').value,
                textColor: getField('slide-text-color').value,
                fontFamily: getField('slide-font-family').value,
                fontSize: getField('slide-font-size').value,
                fontWeight: getField('slide-font-weight').checked ? 900 : 400,
                align: getField('slide-align').value,
                valign: getField('slide-valign').value,
                motionSpeed: getField('slide-motion-speed').value,
                hue: getField('slide-hue').value,
                hueCycle: getField('slide-hue-cycle').checked,
                invert: getField('slide-invert').checked,
                strobe: getField('slide-strobe').checked,
                strobeRate: getField('slide-strobe-rate').value,
                seed: composerSeed,
            });
        }

        function updateChrome() {
            const limitedText = root.truncateSlideText(message.value);
            if (limitedText !== message.value) message.value = limitedText;
            const config = readConfig();
            charCount.textContent = `${root.countSlideText(message.value)}/${root.SLIDE_MAX_TEXT}`;
            hueValue.textContent = `${config.hue}°`;
            motionValue.textContent = config.motionSpeed === 0 ? 'Still' : `${config.motionSpeed.toFixed(2).replace(/\.00$/, '')}×`;
            strobeValue.textContent = `${config.strobeRate.toFixed(1)} Hz`;
            strobeWarning.classList.toggle('hidden', !config.strobe);
            patternGrid.querySelectorAll('[data-slide-pattern]').forEach(button => {
                const active = button.dataset.slidePattern === selectedPattern;
                button.classList.toggle('active', active);
                button.setAttribute('aria-pressed', String(active));
            });
            const deck = targetDeckId().toUpperCase();
            queueButton.textContent = `Queue on Deck ${deck}`;
            playButton.textContent = `Play on Deck ${deck}`;
        }

        function renderPreview(now) {
            if (overlay.classList.contains('hidden')) return;
            const reducedMotion = root.matchMedia && root.matchMedia('(prefers-reduced-motion: reduce)').matches;
            const config = readConfig();
            const explicitMotion = config.strobe || config.hueCycle;
            const time = reducedMotion && !explicitMotion ? 0 : Math.max(0, (now - openedAt) / 1000);
            root.renderSlideFrame(ctx, config, time, canvas.width, canvas.height);
            animationFrame = requestAnimationFrame(renderPreview);
        }

        function resetForm() {
            const defaults = root.DEFAULT_SLIDE_CONFIG;
            message.value = defaults.text;
            selectedPattern = defaults.pattern;
            getField('slide-bg-color').value = defaults.bgColor;
            getField('slide-accent-color').value = defaults.accentColor;
            getField('slide-text-color').value = defaults.textColor;
            getField('slide-font-family').value = defaults.fontFamily;
            getField('slide-font-size').value = defaults.fontSize;
            getField('slide-font-weight').checked = defaults.fontWeight >= 700;
            getField('slide-align').value = defaults.align;
            getField('slide-valign').value = defaults.valign;
            getField('slide-motion-speed').value = defaults.motionSpeed;
            getField('slide-hue').value = defaults.hue;
            getField('slide-hue-cycle').checked = defaults.hueCycle;
            getField('slide-invert').checked = defaults.invert;
            getField('slide-strobe').checked = defaults.strobe;
            getField('slide-strobe-rate').value = defaults.strobeRate;
            updateChrome();
        }

        function openComposer() {
            restoreFocus = document.activeElement;
            composerSeed = root.crypto && typeof root.crypto.getRandomValues === 'function'
                ? root.crypto.getRandomValues(new Uint32Array(1))[0]
                : Math.floor(Math.random() * 0xffffffff);
            overlay.classList.remove('hidden');
            overlay.setAttribute('aria-hidden', 'false');
            openedAt = performance.now();
            updateChrome();
            cancelAnimationFrame(animationFrame);
            animationFrame = requestAnimationFrame(renderPreview);
            setTimeout(() => { message.focus(); message.select(); }, 0);
        }

        function closeComposer() {
            if (overlay.classList.contains('hidden')) return;
            overlay.classList.add('hidden');
            overlay.setAttribute('aria-hidden', 'true');
            cancelAnimationFrame(animationFrame);
            if (restoreFocus && typeof restoreFocus.focus === 'function') restoreFocus.focus();
        }

        function makeItem() {
            const config = root.snapshotSlideConfig(readConfig());
            return {
                name: root.slideName(config),
                type: 'visual',
                visualId: root.SLIDE_VISUAL_ID,
                visualConfig: config,
            };
        }

        function sendToDeck(playNow) {
            const deckId = targetDeckId();
            const deck = typeof options.getDeck === 'function' ? options.getDeck(deckId) : null;
            if (!deck) return;
            const item = makeItem();
            deck.addToPlaylist(item);
            if (playNow) {
                deck.loadItem(deck.playlist.length - 1);
                deck.play();
                if (typeof options.updatePlayButton === 'function') options.updatePlayButton(deckId, true);
            }
            if (typeof options.showToast === 'function') {
                options.showToast(`${playNow ? 'Playing' : 'Queued'} ${item.name} on Deck ${deckId.toUpperCase()}`);
            }
        }

        // Build preset buttons from the shared whitelist so UI and validation
        // cannot drift apart.
        patternGrid.innerHTML = '';
        root.SLIDE_PATTERNS.forEach(pattern => {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'slide-pattern';
            button.dataset.slidePattern = pattern;
            button.textContent = PATTERN_LABELS[pattern] || pattern;
            button.setAttribute('aria-pressed', 'false');
            button.addEventListener('click', () => {
                selectedPattern = pattern;
                updateChrome();
            });
            patternGrid.appendChild(button);
        });

        form.addEventListener('submit', event => event.preventDefault());
        form.addEventListener('input', updateChrome);
        form.addEventListener('change', updateChrome);
        trigger.addEventListener('click', openComposer);
        getField('slide-composer-close').addEventListener('click', closeComposer);
        getField('slide-reset-btn').addEventListener('click', resetForm);
        queueButton.addEventListener('click', () => sendToDeck(false));
        playButton.addEventListener('click', () => sendToDeck(true));
        overlay.addEventListener('pointerdown', event => {
            if (event.target === overlay) closeComposer();
        });
        overlay.addEventListener('keydown', event => {
            // Keep global mixer shortcuts dormant while the dialog is active.
            event.stopPropagation();
            if (event.key === 'Escape') {
                event.preventDefault();
                closeComposer();
                return;
            }
            if (event.key !== 'Tab') return;
            const focusable = Array.from(overlay.querySelectorAll(
                'button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled])',
            )).filter(element => element.offsetParent !== null);
            if (!focusable.length) return;
            const first = focusable[0];
            const last = focusable[focusable.length - 1];
            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault();
                last.focus();
            } else if (!event.shiftKey && document.activeElement === last) {
                event.preventDefault();
                first.focus();
            }
        });

        resetForm();
        return { open: openComposer, close: closeComposer, readConfig };
    }

    root.setupSlideComposer = setupSlideComposer;
    if (typeof module !== 'undefined' && module.exports) module.exports = { setupSlideComposer };
}(typeof window !== 'undefined' ? window : globalThis));
