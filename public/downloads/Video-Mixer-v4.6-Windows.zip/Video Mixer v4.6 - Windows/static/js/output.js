/**
 * Output Window Renderer
 * Receives state from the main mixer window via BroadcastChannel
 * and renders the mixed output independently at full resolution.
 * Now with audio passthrough and per-deck FX support.
 */

const canvas = document.getElementById('output-canvas');
const ctx = canvas.getContext('2d');
const statusEl = document.getElementById('status');

let state = null;
let connected = false;
let lastStateTime = 0;

function createOutputDeck() {
    const deck = {
        player: null, image: null, visual: null,
        currentSrc: '', sourceRevision: null, cueRevision: null, type: null, lastState: null,
        visualId: null, visualConfig: null,
    };
    deck.player = new SeamlessVideoLoop(document.createElement('video'), {
        fadeSeconds: SEAMLESS_LOOP_FADE_SECONDS,
        shouldLoop: () => Boolean(deck.lastState && deck.lastState.seamlessLoop),
    });
    return deck;
}

const decks = {
    a: createOutputDeck(),
    b: createOutputDeck(),
};

const deckFxBuffers = {
    a: document.createElement('canvas'),
    b: document.createElement('canvas'),
};

// Configure video elements — audio enabled for output window
for (const id of ['a', 'b']) {
    for (const video of decks[id].player.videos) {
        video.playsInline = true;
        video.preload = 'auto';
        video.crossOrigin = 'anonymous';
        // Start muted, unmute once connected
        video.muted = true;
    }
}

// Audio unmute on first user interaction (browser policy)
let audioUnlocked = false;
function unlockAudio() {
    if (audioUnlocked) return;
    audioUnlocked = true;
    for (const id of ['a', 'b']) {
        decks[id].player.setMuted(false);
    }
    document.removeEventListener('click', unlockAudio);
    document.removeEventListener('keydown', unlockAudio);
}
document.addEventListener('click', unlockAudio);
document.addEventListener('keydown', unlockAudio);

const channel = new BroadcastChannel('mixer-sync');
channel.onmessage = (e) => {
    state = e.data;
    lastStateTime = performance.now();

    if (!connected) {
        connected = true;
        statusEl.textContent = 'Connected — click to enable audio';
        statusEl.classList.add('connected');
        setTimeout(() => { statusEl.style.opacity = '0'; }, 4000);
    }

    syncDeck('a', state.deckA);
    syncDeck('b', state.deckB);
};

// Send heartbeat
setInterval(() => {
    channel.postMessage({ type: 'output-heartbeat' });
}, 1000);


function syncDeck(id, deckState) {
    if (!deckState) return;
    const d = decks[id];
    d.lastState = deckState;
    const mediaUrl = deckState.mediaUrl || '';
    const sourceRevision = deckState.sourceRevision ?? null;
    const cueRevision = deckState.cueRevision ?? null;

    if (!mediaUrl) {
        const hadSource = Boolean(d.currentSrc || d.type || d.image || d.visual
            || d.player.videos.some(video => video.hasAttribute('src')));
        if (hadSource) {
            d.player.clearSource();
        }
        d.currentSrc = '';
        d.sourceRevision = sourceRevision;
        d.cueRevision = cueRevision;
        d.type = null;
        d.image = null;
        d.visual = null;
        d.visualId = null;
        d.visualConfig = null;
        return;
    }

    const sourceChanged = mediaUrl !== d.currentSrc
        || deckState.mediaType !== d.type
        || sourceRevision !== d.sourceRevision
        || cueRevision !== d.cueRevision;

    if (sourceChanged) {
        d.currentSrc = mediaUrl;
        d.sourceRevision = sourceRevision;
        d.cueRevision = cueRevision;
        d.type = deckState.mediaType;

        if (deckState.mediaType === 'video') {
            d.image = null;
            d.visual = null;
            d.visualId = null;
            d.visualConfig = null;
            d.player.setSource(mediaUrl);
            d.player.setPlaybackRate(deckState.speed || 1);
            if (Number.isFinite(deckState.currentTime)) d.player.seek(deckState.currentTime);
            if (deckState.playing) {
                d.player.play();
            }
        } else if (deckState.mediaType === 'visual') {
            // Rebuild generated media locally at output resolution. The config
            // is plain structured data broadcast by the main mixer.
            d.image = null;
            d.player.clearSource();
            const visualId = deckState.visualId || mediaUrl.slice('visual:'.length);
            const vw = (state && state.outputW) || 1280;
            const vh = (state && state.outputH) || 720;
            d.visualId = visualId;
            d.visualConfig = deckState.visualConfig && typeof deckState.visualConfig === 'object'
                ? JSON.parse(JSON.stringify(deckState.visualConfig))
                : null;
            d.visual = window.createVisualInstance
                ? createVisualInstance(visualId, vw, vh, d.visualConfig || {})
                : null;
            if (d.visual && typeof d.visual.renderAt === 'function') {
                d.visual.renderAt(Number(deckState.visualTime) || 0);
                d.visual._last = performance.now();
            }
        } else {
            d.visual = null;
            d.visualId = null;
            d.visualConfig = null;
            d.player.clearSource();
            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = () => {
                if (d.currentSrc === mediaUrl
                    && d.sourceRevision === sourceRevision
                    && d.cueRevision === cueRevision) d.image = img;
            };
            img.onerror = () => {
                if (d.currentSrc === mediaUrl
                    && d.sourceRevision === sourceRevision
                    && d.cueRevision === cueRevision) d.image = null;
            };
            img.src = mediaUrl;
        }
    }

    if (deckState.mediaType === 'visual' && d.visual && state) {
        const vw = state.outputW || 1280;
        const vh = state.outputH || 720;
        if (d.visual.canvas.width !== vw || d.visual.canvas.height !== vh) {
            const visualTime = Number.isFinite(Number(deckState.visualTime))
                ? Number(deckState.visualTime)
                : d.visual._t;
            d.visual = createVisualInstance(d.visualId, vw, vh, d.visualConfig || {});
            if (d.visual && typeof d.visual.renderAt === 'function') {
                d.visual.renderAt(visualTime);
                d.visual._last = performance.now();
            }
        }
    }

    // The main window is the visual clock. Re-rendering at its broadcast phase
    // keeps fast hue/invert/strobe frames aligned with recording and Screenfolk.
    if (deckState.mediaType === 'visual' && d.visual
        && Number.isFinite(Number(deckState.visualTime))) {
        d.visual.renderAt(Number(deckState.visualTime));
        d.visual._last = performance.now();
    }

    if (deckState.mediaType === 'video') {
        if (deckState.playing && !d.player.playing) {
            d.player.play();
        } else if (!deckState.playing && d.player.playing) {
            d.player.pause();
        }

        // Sync time if noticeably drifted.
        const activeVideo = d.player.active;
        if (deckState.currentTime !== undefined && activeVideo.duration) {
            const rawDrift = Math.abs(activeVideo.currentTime - deckState.currentTime);
            const drift = deckState.seamlessLoop
                ? Math.min(rawDrift, Math.abs(activeVideo.duration - rawDrift))
                : rawDrift;
            // Both windows run their own identical overlap. Avoid throwing away
            // a decoded incoming frame with a hard seek during that crossover.
            if (drift > 0.75 && !d.player.transitioning) {
                d.player.seek(deckState.currentTime);
            }
        }

        if (deckState.speed && d.player.playbackRate !== deckState.speed) {
            d.player.setPlaybackRate(deckState.speed);
        }

        // Sync volume based on crossfader position
        if (state) {
            const cf = state.crossfade || 0;
            const vol = deckState.volume ?? 1;
            if (id === 'a') {
                d.player.setVolume(vol * (1 - cf));
            } else {
                d.player.setVolume(vol * cf);
            }
        }
    }
}


function getDrawable(id) {
    const d = decks[id];
    if (d.type === 'video') return d.player.getBlend().base;
    if (d.type === 'image' && d.image) return d.image;
    if (d.type === 'visual' && d.visual) return d.visual.canvas;
    return null;
}

function getProcessedDrawable(id, w, h) {
    const d = decks[id];
    const videoBlend = d.type === 'video' ? d.player.getBlend() : null;
    const src = videoBlend ? videoBlend.base : getDrawable(id);
    if (!src) return null;
    const fx = d.lastState && d.lastState.fx;
    const hasFx = Boolean(fx && (fx.brightness !== 100 || fx.contrast !== 100
        || fx.saturate !== 100 || fx.hue !== 0));
    const needsVideoBlend = Boolean(videoBlend && videoBlend.incoming && videoBlend.mix > 0);
    if (!hasFx && !needsVideoBlend) return src;

    const buffer = deckFxBuffers[id];
    if (buffer.width !== w || buffer.height !== h) {
        buffer.width = w;
        buffer.height = h;
    }
    const bctx = buffer.getContext('2d');
    bctx.clearRect(0, 0, w, h);
    bctx.save();
    if (hasFx) {
        bctx.filter = `brightness(${fx.brightness}%) contrast(${fx.contrast}%) saturate(${fx.saturate}%) hue-rotate(${fx.hue}deg)`;
    }
    if (needsVideoBlend) drawSeamlessVideoBlend(bctx, videoBlend, w, h, drawFit);
    else drawFit(bctx, src, w, h);
    bctx.restore();
    return buffer;
}

function tickVisuals(now) {
    for (const id of ['a', 'b']) {
        const d = decks[id];
        if (d.type !== 'visual' || !d.visual || !d.lastState) continue;
        if (!d.lastState.playing) {
            d.visual._last = now; // freeze without a time jump on resume
            continue;
        }
        d.visual.tick(now, d.lastState.speed || 1, (state && state.bpm) || 0, 0);
    }
}


function drawFit(ctx, src, canvasW, canvasH) {
    const srcW = src.videoWidth || src.naturalWidth || src.width;
    const srcH = src.videoHeight || src.naturalHeight || src.height;
    if (!srcW || !srcH) return;
    const scale = Math.max(canvasW / srcW, canvasH / srcH);
    const drawW = srcW * scale;
    const drawH = srcH * scale;
    const x = (canvasW - drawW) / 2;
    const y = (canvasH - drawH) / 2;
    ctx.drawImage(src, x, y, drawW, drawH);
}


// --- Overlay layer (logo image or text) — mirrors drawOverlay in mixer.js ---

const overlayCache = { url: '', image: null };

function getOverlayImage(ov) {
    if (!ov || !ov.url) {
        overlayCache.url = '';
        overlayCache.image = null;
        return null;
    }
    if (ov.url !== overlayCache.url) {
        overlayCache.url = ov.url;
        overlayCache.image = null;
        const img = new Image();
        img.onload = () => {
            if (overlayCache.url === ov.url) overlayCache.image = img;
        };
        // blob: URLs from the mixer window are valid here — same origin
        img.src = ov.url;
    }
    return overlayCache.image;
}

function drawOverlay(ctx, ov, img, w, h) {
    if (!ov || !ov.enabled) return;
    const hasImage = img && (img.naturalWidth || img.width);
    if (!hasImage && !ov.text) return;
    ctx.save();
    ctx.globalAlpha = Math.max(0, Math.min(1, (ov.opacity ?? 100) / 100));
    ctx.globalCompositeOperation = ov.blend || 'source-over';
    const margin = Math.round(w * 0.03);
    const pos = ov.pos || 'br';
    if (hasImage) {
        const iw = img.naturalWidth || img.width;
        const ih = img.naturalHeight || img.height;
        const ow = Math.max(8, w * (ov.scale ?? 25) / 100);
        const oh = ow * ih / iw;
        let x = margin, y = margin;
        if (pos === 'tr' || pos === 'br') x = w - ow - margin;
        if (pos === 'bl' || pos === 'br') y = h - oh - margin;
        if (pos === 'c') { x = (w - ow) / 2; y = (h - oh) / 2; }
        ctx.drawImage(img, x, y, ow, oh);
    } else {
        const size = Math.max(10, h * (ov.scale ?? 25) / 250);
        ctx.font = `700 ${size}px 'SF Mono', 'Menlo', 'Consolas', monospace`;
        ctx.fillStyle = '#fff';
        ctx.shadowColor = 'rgba(0,0,0,0.7)';
        ctx.shadowBlur = size / 6;
        let x = margin, y = margin;
        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';
        if (pos === 'tr' || pos === 'br') { x = w - margin; ctx.textAlign = 'right'; }
        if (pos === 'bl' || pos === 'br') { y = h - margin; ctx.textBaseline = 'bottom'; }
        if (pos === 'c') { x = w / 2; y = h / 2; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; }
        ctx.fillText(ov.text, x, y);
    }
    ctx.restore();
}


function render() {
    const dpr = window.devicePixelRatio || 1;
    const w = Math.max(1, Math.round(window.innerWidth * dpr));
    const h = Math.max(1, Math.round(window.innerHeight * dpr));
    if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
    }

    tickVisuals(performance.now());

    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, w, h);

    if (state) {
        const srcA = getProcessedDrawable('a', w, h);
        const srcB = getProcessedDrawable('b', w, h);
        const cf = state.crossfade || 0;

        // Apply master FX
        if (state.fx) {
            const fx = state.fx;
            ctx.filter = `brightness(${fx.brightness}%) contrast(${fx.contrast}%) saturate(${fx.saturate}%) hue-rotate(${fx.hue}deg)`;
        }

        const transId = state.transition || 'crossfade';
        const transition = window.TransitionRegistry.get(transId);

        transition.render(ctx, srcA, srcB, cf, w, h, drawFit);

        ctx.filter = 'none';
        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = 'source-over';

        // Overlay rides above master FX, exactly as in the mixer preview
        drawOverlay(ctx, state.overlay, getOverlayImage(state.overlay), w, h);
    }

    // Check for disconnect
    if (connected && performance.now() - lastStateTime > 3000) {
        connected = false;
        statusEl.textContent = 'Disconnected';
        statusEl.classList.remove('connected');
        statusEl.style.opacity = '1';
    }

    requestAnimationFrame(render);
}

// Auto-hide cursor
let cursorTimeout;
document.addEventListener('mousemove', () => {
    document.body.classList.add('show-cursor');
    clearTimeout(cursorTimeout);
    cursorTimeout = setTimeout(() => {
        document.body.classList.remove('show-cursor');
    }, 3000);
});

// Fullscreen on double-click
canvas.addEventListener('dblclick', () => {
    if (document.fullscreenElement) {
        document.exitFullscreen();
    } else {
        document.documentElement.requestFullscreen();
    }
});

render();
