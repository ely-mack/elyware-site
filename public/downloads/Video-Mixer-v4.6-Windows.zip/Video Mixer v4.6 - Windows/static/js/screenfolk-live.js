/**
 * Screenfolk live output adapter for ELYWARE Video Mixer v4.5.
 *
 * The mixer remains loopback-only. This captures the existing program canvas
 * and publishes video through a one-use, screen-scoped WebRTC session.
 */
(function () {
    'use strict';

    const ALLOWED_SERVERS = new Set([
        'https://screenfolk.com',
        'http://localhost:3000',
        'http://127.0.0.1:3000',
    ]);
    const POLL_CONNECTING_MS = 750;
    const POLL_LIVE_MS = 2000;
    const MAX_VIDEO_BITRATE = 8_000_000;
    const CONNECT_TIMEOUT_MS = 30_000;
    const SIGNAL_REQUEST_TIMEOUT_MS = 8_000;
    const CONTROL_PLANE_STALE_TIMEOUT_MS = 20_000;
    const HANDSHAKE_TIMEOUT_MS = 20_000;
    window.screenfolkLiveOutputActive = false;

    const state = {
        active: false,
        sessionId: '',
        token: '',
        screenName: '',
        server: 'https://screenfolk.com',
        iceServers: [],
        relayAvailable: false,
        peer: null,
        stream: null,
        track: null,
        offerSent: false,
        remoteReady: false,
        afterSequence: 0,
        localIce: [],
        remoteIce: [],
        pollTimer: null,
        retryTimer: null,
        disconnectTimer: null,
        handshakeTimer: null,
        safetyTimer: null,
        pollController: null,
        polling: false,
        generation: 0,
        expiresAt: 0,
        lastControlPlaneAt: 0,
    };

    let overlay, codeInput, serverInput, message, connectButton, stopButton, liveButton;
    let pendingConnectionCode = '';
    let pendingConnectionRequestId = '';

    document.addEventListener('DOMContentLoaded', () => {
        overlay = document.getElementById('screenfolk-live-overlay');
        codeInput = document.getElementById('screenfolk-live-code');
        serverInput = document.getElementById('screenfolk-live-server');
        message = document.getElementById('screenfolk-live-message');
        connectButton = document.getElementById('screenfolk-live-connect');
        stopButton = document.getElementById('screenfolk-live-stop');
        liveButton = document.getElementById('screenfolk-live-btn');
        if (!overlay || !codeInput || !serverInput || !message || !connectButton || !stopButton || !liveButton) return;

        try {
            const saved = localStorage.getItem('screenfolk-live-server');
            if (saved && ALLOWED_SERVERS.has(saved)) serverInput.value = saved;
        } catch {}

        liveButton.addEventListener('click', openDialog);
        document.getElementById('screenfolk-live-close').addEventListener('click', closeDialog);
        overlay.addEventListener('mousedown', event => {
            if (event.target === overlay) closeDialog();
        });
        codeInput.addEventListener('input', () => {
            codeInput.value = formatCode(codeInput.value);
            if (codeInput.value !== pendingConnectionCode) {
                pendingConnectionCode = '';
                pendingConnectionRequestId = '';
            }
        });
        connectButton.addEventListener('click', connect);
        stopButton.addEventListener('click', () => stop(true));
        window.addEventListener('pagehide', () => {
            const remote = remoteSession();
            resetLocalState();
            if (remote) void endRemoteSession(remote, true);
        });
        document.addEventListener('keydown', event => {
            if (event.key === 'Escape' && !overlay.classList.contains('screenfolk-live-hidden')) closeDialog();
        });
    });

    function openDialog() {
        overlay.classList.remove('screenfolk-live-hidden');
        if (!state.active) setTimeout(() => codeInput.focus(), 0);
    }

    function closeDialog() {
        overlay.classList.add('screenfolk-live-hidden');
    }

    function setMessage(text, tone) {
        message.textContent = text;
        message.classList.toggle('screenfolk-live-error', tone === 'error');
        message.classList.toggle('screenfolk-live-ready', tone === 'ready');
    }

    function setToolbarStatus(status) {
        liveButton.classList.toggle('screenfolk-live-connecting', status === 'connecting');
        liveButton.classList.toggle('screenfolk-live-on', status === 'live');
        liveButton.innerHTML = status === 'live'
            ? '&#x25CF; LIVE'
            : status === 'connecting'
                ? '&#x25CF; Connecting'
                : '&#x25CF; Screenfolk';
    }

    async function connect() {
        if (state.active) return;
        const code = formatCode(codeInput.value);
        if (!/^[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(code)) {
            setMessage('Enter the 12-character one-time code from the exact Screenfolk player.', 'error');
            codeInput.focus();
            return;
        }
        if (typeof RTCPeerConnection === 'undefined' || !mixer || !mixer.canvas || !mixer.canvas.captureStream) {
            setMessage('This browser cannot publish the mixer canvas with WebRTC.', 'error');
            return;
        }
        let server;
        try {
            server = normalizedServer(serverInput.value);
        } catch (error) {
            setMessage(error.message, 'error');
            return;
        }

        connectButton.disabled = true;
        codeInput.disabled = true;
        serverInput.disabled = true;
        setToolbarStatus('connecting');
        setMessage('Using the one-time code and preparing the program feed…');
        try {
            const requestId = connectionRequestId(code);
            const response = await fetch(`${server}/api/live-mixer/connect`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code, requestId }),
                cache: 'no-store',
                signal: timeoutSignal(CONNECT_TIMEOUT_MS),
            });
            const payload = await response.json().catch(() => ({}));
            if (!response.ok || typeof payload.sessionId !== 'string' || typeof payload.broadcasterToken !== 'string') {
                throw new Error(payload.error || 'Screenfolk could not connect this mixer');
            }
            const expiresAt = Date.parse(String(payload.expiresAt || ''));
            if (!Number.isFinite(expiresAt) || expiresAt <= Date.now()) {
                throw new Error('Screenfolk returned an invalid live session deadline');
            }
            state.active = true;
            state.generation += 1;
            state.sessionId = payload.sessionId;
            state.token = payload.broadcasterToken;
            state.screenName = typeof payload.screenName === 'string' ? payload.screenName : 'selected player';
            state.server = server;
            state.iceServers = normalizeIceServers(payload.iceServers);
            state.relayAvailable = payload.relayAvailable === true;
            state.afterSequence = 0;
            state.expiresAt = expiresAt;
            state.lastControlPlaneAt = Date.now();
            pendingConnectionCode = '';
            pendingConnectionRequestId = '';
            try { localStorage.setItem('screenfolk-live-server', server); } catch {}
            stopButton.disabled = false;
            codeInput.value = '';
            await startPublisher();
            scheduleSafetyCheck();
            schedulePoll(0);
        } catch (error) {
            const remote = remoteSession();
            resetLocalState();
            if (remote) void endRemoteSession(remote, false);
            setMessage(error instanceof Error ? error.message : 'Screenfolk could not connect this mixer', 'error');
        }
    }

    function captureProgramStream() {
        if (state.stream && state.track && state.track.readyState === 'live') return state.stream;
        state.stream = mixer.canvas.captureStream(0);
        state.track = state.stream.getVideoTracks()[0] || null;
        const manualCapture = state.track && typeof state.track.requestFrame === 'function';
        if (state.track && !manualCapture) {
            state.track.stop();
            state.stream = mixer.canvas.captureStream(30);
            state.track = state.stream.getVideoTracks()[0] || null;
        }
        window.captureScreenfolkLiveFrame = manualCapture && state.track
            ? () => { try { state.track.requestFrame(); } catch {} }
            : null;
        if (!state.track) throw new Error('The mixer program canvas did not provide a video track');
        window.screenfolkLiveOutputActive = true;
        return state.stream;
    }

    async function startPublisher() {
        closePeer();
        if (!state.active) return;
        const generation = state.generation;
        const peer = new RTCPeerConnection({ iceServers: state.iceServers });
        state.peer = peer;
        state.offerSent = false;
        state.remoteReady = false;
        state.localIce = [];
        state.remoteIce = [];
        const stream = captureProgramStream();
        const sender = peer.addTrack(state.track, stream);
        try {
            const parameters = sender.getParameters();
            parameters.encodings = parameters.encodings && parameters.encodings.length ? parameters.encodings : [{}];
            parameters.encodings[0].maxBitrate = MAX_VIDEO_BITRATE;
            await sender.setParameters(parameters);
        } catch {}

        peer.onicecandidate = event => {
            if (!event.candidate || state.peer !== peer || state.generation !== generation) return;
            const candidate = event.candidate.toJSON();
            if (!state.offerSent) state.localIce.push(candidate);
            else void postSignal('ice', candidate, generation).catch(() => {
                if (state.peer === peer && state.generation === generation) state.localIce.push(candidate);
            });
        };
        peer.onconnectionstatechange = () => {
            if (state.peer !== peer || !state.active) return;
            if (peer.connectionState === 'connected') {
                clearTimeout(state.disconnectTimer);
                clearTimeout(state.handshakeTimer);
                state.handshakeTimer = null;
                const relayNote = state.relayAvailable ? 'TURN relay available.' : 'Direct connection; same-network pilot recommended.';
                setMessage(`Program video connected to ${state.screenName}. Waiting for the player to reveal its first frame. ${relayNote}`, 'ready');
                return;
            }
            if (peer.connectionState === 'disconnected') {
                clearTimeout(state.disconnectTimer);
                state.disconnectTimer = setTimeout(() => retryPublisher(), 5000);
            }
            if (peer.connectionState === 'failed') retryPublisher();
        };

        const offer = await peer.createOffer();
        await peer.setLocalDescription(offer);
        if (state.peer !== peer || !state.active || state.generation !== generation) return;
        await postSignal('offer', { type: 'offer', sdp: offer.sdp || '' }, generation);
        state.offerSent = true;
        clearTimeout(state.handshakeTimer);
        state.handshakeTimer = setTimeout(() => {
            if (state.peer === peer && state.active && state.generation === generation && peer.connectionState !== 'connected') {
                retryPublisher('The player did not finish connecting. Retrying the live feed…');
            }
        }, HANDSHAKE_TIMEOUT_MS);
        await flushLocalIce(generation);
        setMessage(`Connected to ${state.screenName}. Waiting for the Screenfolk player…`);
    }

    function retryPublisher(reason) {
        if (!state.active || state.retryTimer) return;
        const generation = state.generation;
        setToolbarStatus('connecting');
        setMessage(reason || 'The player connection dropped. Its playlist has resumed while the mixer reconnects.');
        closePeer();
        state.retryTimer = setTimeout(() => {
            state.retryTimer = null;
            if (!state.active || state.generation !== generation) return;
            void startPublisher().catch(error => {
                setMessage(`Reconnect failed: ${error.message || error}`, 'error');
                retryPublisher();
            });
        }, 2000);
    }

    async function postSignal(kind, payload, generation = state.generation) {
        if (!state.active || generation !== state.generation) throw new Error('Live session is not active');
        const remote = remoteSession();
        if (!remote) throw new Error('Live session is not active');
        const response = await fetch(remote.url, {
            method: 'POST',
            headers: { ...remote.headers, 'Content-Type': 'application/json' },
            body: JSON.stringify({ kind, payload }),
            cache: 'no-store',
            signal: timeoutSignal(SIGNAL_REQUEST_TIMEOUT_MS),
        });
        if (generation !== state.generation) throw new Error('Live session changed');
        if (!response.ok) {
            const result = await response.json().catch(() => ({}));
            throw new Error(result.error || 'Live signal was rejected');
        }
    }

    async function flushLocalIce(generation = state.generation) {
        if (!state.offerSent || !state.localIce.length) return;
        const queued = state.localIce;
        state.localIce = [];
        for (let index = 0; index < queued.length; index += 1) {
            try {
                await postSignal('ice', queued[index], generation);
            } catch (error) {
                if (state.generation === generation) state.localIce.unshift(...queued.slice(index));
                throw error;
            }
        }
    }

    function schedulePoll(delay) {
        clearTimeout(state.pollTimer);
        if (!state.active) return;
        state.pollTimer = setTimeout(() => void pollSignals(), delay);
    }

    async function pollSignals() {
        if (!state.active || state.polling) return;
        const generation = state.generation;
        const sessionId = state.sessionId;
        const remote = remoteSession();
        if (!remote) return;
        const controller = new AbortController();
        let requestTimedOut = false;
        let requestTimeout = setTimeout(() => {
            requestTimedOut = true;
            controller.abort();
        }, SIGNAL_REQUEST_TIMEOUT_MS);
        const clearRequestTimeout = () => {
            clearTimeout(requestTimeout);
            requestTimeout = null;
        };
        state.pollController = controller;
        state.polling = true;
        try {
            const response = await fetch(`${remote.url}?after=${state.afterSequence}`, {
                headers: remote.headers,
                cache: 'no-store',
                signal: controller.signal,
            });
            if (!sameSession(generation, sessionId) || controller.signal.aborted) return;
            if (response.status === 401 || response.status === 403) {
                throw new Error('The Screenfolk live session ended or expired');
            }
            if (!response.ok) throw new Error('Screenfolk signalling is temporarily unavailable');
            const payload = await response.json();
            clearRequestTimeout();
            if (!sameSession(generation, sessionId) || controller.signal.aborted) return;
            if (payload.active !== true) throw new Error('The Screenfolk live session ended');
            const expiresAt = Date.parse(String(payload.expiresAt || ''));
            if (!Number.isFinite(expiresAt) || expiresAt <= Date.now()) {
                throw new Error('The Screenfolk live session expired');
            }
            state.expiresAt = Math.min(state.expiresAt || expiresAt, expiresAt);
            state.lastControlPlaneAt = Date.now();
            const signals = normalizeSignals(payload.signals);
            if (signals.length) {
                await processSignals(signals, generation);
                if (!sameSession(generation, sessionId) || controller.signal.aborted) return;
                state.afterSequence = Math.max(state.afterSequence, ...signals.map(signal => signal.sequence));
            }
            if (state.offerSent && state.localIce.length) await flushLocalIce(generation);
        } catch (error) {
            if (!sameSession(generation, sessionId) || (controller.signal.aborted && !requestTimedOut)) return;
            if (/ended|expired/.test(String(error.message || error))) {
                resetLocalState();
                setMessage('The Screenfolk live session ended. The player is back on its playlist.');
                return;
            }
        } finally {
            clearRequestTimeout();
            if (state.pollController === controller) state.pollController = null;
            if (state.generation === generation) state.polling = false;
        }
        if (sameSession(generation, sessionId)) schedulePoll(state.remoteReady ? POLL_LIVE_MS : POLL_CONNECTING_MS);
    }

    async function processSignals(signals, generation) {
        const answers = signals.filter(signal => signal.kind === 'answer');
        const playerStates = signals.filter(signal => signal.kind === 'ready' || signal.kind === 'fallback');
        const playerState = playerStates[playerStates.length - 1];
        const latestAnswer = answers[answers.length - 1];
        const ice = signals.filter(signal => signal.kind === 'ice'
            && (!latestAnswer || signal.sequence > latestAnswer.sequence));
        const peer = state.peer;
        if (latestAnswer && peer && peer.signalingState === 'have-local-offer') {
            await peer.setRemoteDescription({ type: 'answer', sdp: latestAnswer.payload.sdp });
            if (state.generation !== generation || state.peer !== peer) return;
            const queued = state.remoteIce;
            state.remoteIce = [];
            for (const candidate of queued) await peer.addIceCandidate(candidate).catch(() => undefined);
        }
        for (const signal of ice) {
            if (state.generation !== generation) return;
            if (!state.peer || !state.peer.remoteDescription) state.remoteIce.push(signal.payload);
            else await state.peer.addIceCandidate(signal.payload).catch(() => undefined);
        }
        if (playerState && playerState.kind === 'ready') {
            state.remoteReady = true;
            setToolbarStatus('live');
            setMessage(`LIVE on ${state.screenName}. Stop here or in Screenfolk to return immediately to the playlist.`, 'ready');
        } else if (playerState && playerState.kind === 'fallback') {
            retryPublisher(`The player returned to its playlist while the live feed reconnects to ${state.screenName}.`);
        }
    }

    function stop(notifyServer) {
        const remote = remoteSession();
        resetLocalState();
        if (notifyServer && remote) void endRemoteSession(remote, false);
        setMessage('Live output stopped. The Screenfolk player is back on its playlist.');
    }

    async function endRemoteSession(remote, keepalive) {
        await fetch(remote.url, {
            method: 'DELETE',
            headers: remote.headers,
            cache: 'no-store',
            keepalive: Boolean(keepalive),
            signal: timeoutSignal(3000),
        });
    }

    function resetLocalState() {
        clearTimeout(state.pollTimer);
        clearTimeout(state.retryTimer);
        clearTimeout(state.disconnectTimer);
        clearTimeout(state.handshakeTimer);
        clearTimeout(state.safetyTimer);
        if (state.pollController) state.pollController.abort();
        state.pollTimer = null;
        state.retryTimer = null;
        state.disconnectTimer = null;
        state.handshakeTimer = null;
        state.safetyTimer = null;
        state.pollController = null;
        state.active = false;
        state.generation += 1;
        closePeer();
        if (state.track) state.track.stop();
        state.stream = null;
        state.track = null;
        window.captureScreenfolkLiveFrame = null;
        window.screenfolkLiveOutputActive = false;
        state.sessionId = '';
        state.token = '';
        state.screenName = '';
        state.afterSequence = 0;
        state.iceServers = [];
        state.relayAvailable = false;
        state.remoteReady = false;
        state.polling = false;
        state.expiresAt = 0;
        state.lastControlPlaneAt = 0;
        connectButton.disabled = false;
        codeInput.disabled = false;
        serverInput.disabled = false;
        stopButton.disabled = true;
        setToolbarStatus('idle');
    }

    function closePeer() {
        clearTimeout(state.disconnectTimer);
        clearTimeout(state.handshakeTimer);
        state.disconnectTimer = null;
        state.handshakeTimer = null;
        if (state.peer) state.peer.close();
        state.peer = null;
        state.offerSent = false;
        state.remoteReady = false;
        state.localIce = [];
        state.remoteIce = [];
    }

    function scheduleSafetyCheck() {
        clearTimeout(state.safetyTimer);
        if (!state.active) return;
        state.safetyTimer = setTimeout(() => {
            if (!state.active) return;
            const now = Date.now();
            if (state.expiresAt > 0 && now >= state.expiresAt) {
                resetLocalState();
                setMessage('The four-hour Screenfolk live session ended. The player is back on its playlist.');
                return;
            }
            if (state.lastControlPlaneAt > 0 && now - state.lastControlPlaneAt > CONTROL_PLANE_STALE_TIMEOUT_MS) {
                resetLocalState();
                setMessage('The Screenfolk control connection was lost. Live output stopped safely while the player returned to its playlist.', 'error');
                return;
            }
            scheduleSafetyCheck();
        }, 1_000);
    }

    function signalUrl() {
        return `${state.server}/api/live-mixer/${encodeURIComponent(state.sessionId)}/signals`;
    }

    function remoteSession() {
        if (!state.active || !state.sessionId || !state.token) return null;
        return { url: signalUrl(), headers: authHeaders(false) };
    }

    function sameSession(generation, sessionId) {
        return state.active && state.generation === generation && state.sessionId === sessionId;
    }

    function timeoutSignal(milliseconds) {
        if (typeof AbortSignal !== 'undefined' && typeof AbortSignal.timeout === 'function') {
            return AbortSignal.timeout(milliseconds);
        }
        const controller = new AbortController();
        setTimeout(() => controller.abort(), milliseconds);
        return controller.signal;
    }

    function authHeaders(json) {
        const headers = { Authorization: `Bearer ${state.token}` };
        if (json) headers['Content-Type'] = 'application/json';
        return headers;
    }

    function normalizedServer(value) {
        const url = new URL(String(value || '').trim());
        const origin = url.origin;
        if (!ALLOWED_SERVERS.has(origin)) throw new Error('Use screenfolk.com, or the listed local Screenfolk development server.');
        return origin;
    }

    function formatCode(value) {
        const compact = String(value || '').toUpperCase().replace(/[^A-Z2-9]/g, '').slice(0, 12);
        return [compact.slice(0, 4), compact.slice(4, 8), compact.slice(8, 12)].filter(Boolean).join('-');
    }

    function connectionRequestId(code) {
        if (pendingConnectionCode === code && /^[a-f0-9]{64}$/.test(pendingConnectionRequestId)) {
            return pendingConnectionRequestId;
        }
        if (!window.crypto || typeof window.crypto.getRandomValues !== 'function') {
            throw new Error('Secure random connection requests are unavailable in this browser.');
        }
        const bytes = new Uint8Array(32);
        window.crypto.getRandomValues(bytes);
        pendingConnectionCode = code;
        pendingConnectionRequestId = Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
        return pendingConnectionRequestId;
    }

    function normalizeIceServers(value) {
        if (!Array.isArray(value)) return [];
        return value.filter(server => server && (typeof server.urls === 'string' || Array.isArray(server.urls)));
    }

    function normalizeSignals(value) {
        if (!Array.isArray(value)) return [];
        return value.filter(signal => signal
            && Number.isSafeInteger(Number(signal.sequence))
            && ['answer', 'ice', 'ready', 'fallback'].includes(signal.kind)
            && signal.payload && typeof signal.payload === 'object')
            .map(signal => ({ sequence: Number(signal.sequence), kind: signal.kind, payload: signal.payload }));
    }
})();
