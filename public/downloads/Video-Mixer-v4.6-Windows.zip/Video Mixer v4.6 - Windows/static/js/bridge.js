/**
 * Stock Bridge for Resolume — front end.
 * Search Pixabay, cache locally, send clips into Resolume slots via the
 * bridge server's proxy to the Resolume REST API.
 */

const bridge = {
    stockStatus: null,
    resolume: null,
    mode: 'discover',
    query: '',
    page: 1,
    total: 0,
    results: [],
    cached: [],
    cachedById: new Map(),
    busy: new Map(),
    errors: {},
    searchToken: 0,
};

const STARTERS = ['concert visual', 'stage lights', 'geometric', 'high contrast', 'abstract loop', 'motion background'];

function $(id) { return document.getElementById(id); }

function escHtml(str) {
    const div = document.createElement('div');
    div.textContent = String(str ?? '');
    return div.innerHTML;
}

let toastTimer = null;
function toast(message) {
    const el = $('bridge-toast');
    el.textContent = message;
    el.classList.add('visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('visible'), 3000);
}

async function jsonFetch(url, options = {}) {
    const resp = await fetch(url, options);
    let data = {};
    try { data = await resp.json(); } catch (e) {}
    const message = data.error && typeof data.error === 'object' ? data.error.message : data.error;
    if (!resp.ok) throw new Error(message || `Request failed (${resp.status})`);
    return data;
}

function assetId(asset) {
    return String(asset && (asset.assetId != null ? asset.assetId : asset.id != null ? asset.id : ''));
}

function duration(seconds) {
    const n = Math.max(0, Math.round(Number(seconds) || 0));
    return n ? `${Math.floor(n / 60)}:${String(n % 60).padStart(2, '0')}` : '';
}

// ------------------------------------------------------------
// Resolume connection
// ------------------------------------------------------------

async function refreshResolume() {
    try {
        bridge.resolume = await jsonFetch('/api/bridge/status');
    } catch (e) {
        bridge.resolume = { connected: false, error: e.message };
    }
    renderResolumeStatus();
}

function renderResolumeStatus() {
    const el = $('resolume-status');
    const r = bridge.resolume;
    if (r && r.connected) {
        el.className = 'conn-ok';
        el.innerHTML = `<i></i> ${escHtml((r.product || 'RESOLUME').toUpperCase())} ${escHtml(r.version || '')} · ${escHtml(r.host)}:${escHtml(String(r.port))}`;
    } else {
        el.className = 'conn-bad';
        el.innerHTML = '<i></i> RESOLUME OFFLINE';
        el.title = (r && r.error) || '';
    }
    renderTargetBar();
}

function renderTargetBar() {
    const layerSel = $('target-layer');
    const clipSel = $('target-clip');
    const hint = $('target-hint');
    const r = bridge.resolume;
    const layers = (r && r.connected && Array.isArray(r.layers)) ? r.layers : [];
    const previous = layerSel.value;
    layerSel.innerHTML = '';
    if (layers.length) {
        layers.forEach(layer => {
            const opt = document.createElement('option');
            opt.value = layer.index;
            opt.textContent = `${layer.index}: ${layer.name}`;
            layerSel.appendChild(opt);
        });
        if ([...layerSel.options].some(o => o.value === previous)) layerSel.value = previous;
    } else {
        for (let i = 1; i <= 8; i++) {
            const opt = document.createElement('option');
            opt.value = i;
            opt.textContent = `Layer ${i}`;
            layerSel.appendChild(opt);
        }
    }
    const layer = layers.find(l => String(l.index) === layerSel.value);
    const clipPrev = clipSel.value;
    clipSel.innerHTML = '<option value="auto">Auto (next free)</option>';
    const count = layer ? Math.max(layer.clipCount, 1) : 12;
    for (let i = 1; i <= count; i++) {
        const opt = document.createElement('option');
        opt.value = i;
        opt.textContent = `Slot ${i}`;
        clipSel.appendChild(opt);
    }
    if ([...clipSel.options].some(o => o.value === clipPrev)) clipSel.value = clipPrev;
    hint.textContent = layer && layer.freeClip
        ? `Next free: slot ${layer.freeClip}`
        : (layer ? 'No free slot — pick one to overwrite' : '');
}

function setupSettings() {
    const drawer = $('settings-drawer');
    $('settings-btn').addEventListener('click', async () => {
        drawer.classList.toggle('hidden');
        if (!drawer.classList.contains('hidden')) {
            try {
                const cfg = await jsonFetch('/api/bridge/config');
                $('resolume-host').value = cfg.host;
                $('resolume-port').value = cfg.port;
            } catch (e) {}
        }
    });
    $('settings-save').addEventListener('click', async () => {
        try {
            await jsonFetch('/api/bridge/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    host: $('resolume-host').value.trim() || '127.0.0.1',
                    port: parseInt($('resolume-port').value) || 8080,
                }),
            });
            drawer.classList.add('hidden');
            toast('Saved — reconnecting');
            refreshResolume();
        } catch (e) {
            toast(`Could not save: ${e.message}`);
        }
    });
}

// ------------------------------------------------------------
// Stock search / cache
// ------------------------------------------------------------

async function refreshStockStatus() {
    try {
        bridge.stockStatus = await jsonFetch('/api/stock/status');
    } catch (e) {
        bridge.stockStatus = null;
    }
    const summary = $('cache-summary');
    if (bridge.stockStatus) {
        const mb = (Number(bridge.stockStatus.cacheBytes) || 0) / (1024 * 1024);
        summary.textContent = `${bridge.stockStatus.cacheCount} cached · ${mb.toFixed(mb >= 100 ? 0 : 1)} MB`;
    }
    render();
}

async function loadCache() {
    try {
        const data = await jsonFetch('/api/stock/cache');
        bridge.cached = Array.isArray(data.items) ? data.items : [];
        bridge.cachedById.clear();
        bridge.cached.forEach(item => bridge.cachedById.set(assetId(item), item));
    } catch (e) {
        bridge.cached = [];
    }
    render();
}

async function search(query, page = 1) {
    const q = String(query || '').trim();
    if (!q) return;
    const token = ++bridge.searchToken;
    bridge.mode = 'discover';
    bridge.query = q;
    bridge.page = Math.max(1, page);
    $('search-input').value = q;
    setMode('discover');
    setStatus('loading', `Searching Pixabay for “${q}”...`);
    $('bridge-content').innerHTML = '<div class="bridge-loading">Searching…</div>';
    try {
        const data = await jsonFetch(`/api/stock/search?q=${encodeURIComponent(q)}&page=${bridge.page}`);
        if (token !== bridge.searchToken) return;
        bridge.results = Array.isArray(data.results) ? data.results : [];
        bridge.total = Number(data.total) || bridge.results.length;
        bridge.errors = {};
    } catch (e) {
        if (token !== bridge.searchToken) return;
        bridge.results = [];
        bridge.total = 0;
        setStatus('error', e.message);
        $('bridge-content').innerHTML = `<div class="bridge-empty"><strong>Search failed</strong><p>${escHtml(e.message)}</p></div>`;
        return;
    }
    render();
}

function setMode(mode) {
    bridge.mode = mode;
    document.querySelectorAll('.bridge-mode').forEach(btn =>
        btn.classList.toggle('active', btn.dataset.mode === mode));
    if (mode === 'cached') loadCache();
}

function setStatus(kind, text) {
    const el = $('bridge-status');
    el.className = kind || '';
    el.textContent = text || '';
}

function render() {
    const content = $('bridge-content');
    const configured = Boolean(bridge.stockStatus && bridge.stockStatus.configured);

    if (bridge.stockStatus === null) {
        setStatus('loading', 'Checking Pixabay connection…');
        return;
    }

    if (!configured) {
        setStatus('warning', 'PIXABAY · API KEY REQUIRED');
        content.innerHTML = `<div class="bridge-setup">
            <strong>Connect Pixabay</strong>
            <p>Enter a Pixabay API key to search free stock video. The same key and cache are shared with Video Mixer.</p>
            <form id="key-form">
                <input type="password" name="apiKey" placeholder="Pixabay API key" autocomplete="off" required>
                <button type="submit">Save API key</button>
            </form>
            <p class="setup-links"><a href="https://pixabay.com/api/docs/" target="_blank" rel="noreferrer">Get a free key / API docs</a></p>
        </div>`;
        const form = document.getElementById('key-form');
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            try {
                await jsonFetch('/api/stock/config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ apiKey: form.apiKey.value.trim() }),
                });
                toast('Pixabay key saved');
                await refreshStockStatus();
                if (bridge.stockStatus && bridge.stockStatus.configured) search(STARTERS[0]);
            } catch (err) {
                toast(`Could not save key: ${err.message}`);
            }
        });
        return;
    }

    if (bridge.mode === 'cached') {
        setStatus('online', `${bridge.cached.length} cached clip${bridge.cached.length === 1 ? '' : 's'}`);
        content.innerHTML = bridge.cached.length
            ? `<div class="bridge-grid">${bridge.cached.map(item => card(item, true)).join('')}</div>`
            : '<div class="bridge-empty"><strong>Cache is empty</strong><p>Search Pixabay and send a clip — it caches on the way through.</p></div>';
        return;
    }

    if (!bridge.query) {
        setStatus('online', 'PIXABAY · SEARCH FREE STOCK VIDEO');
        content.innerHTML = `<div class="bridge-welcome">
            <strong>Find footage for the composition</strong>
            <p>Search Pixabay, then send clips straight into Resolume clip slots.</p>
            <div class="bridge-starters">${STARTERS.map(q =>
                `<button type="button" data-starter="${escHtml(q)}">${escHtml(q)}</button>`).join('')}</div>
        </div>`;
        return;
    }

    if (!bridge.results.length) {
        setStatus('online', `No results for “${bridge.query}”`);
        content.innerHTML = '<div class="bridge-empty"><strong>No stock clips found</strong><p>Try a shorter or more general search.</p></div>';
        return;
    }

    setStatus('online', `${bridge.total} results · page ${bridge.page}`);
    const hasNext = bridge.total > bridge.page * 24;
    content.innerHTML = `<div class="bridge-grid">${bridge.results.map(item => card(item, false)).join('')}</div>
        <div class="bridge-pager">
            <button type="button" data-page="${bridge.page - 1}" ${bridge.page <= 1 ? 'disabled' : ''}>Previous</button>
            <span>Page ${bridge.page}</span>
            <button type="button" data-page="${bridge.page + 1}" ${hasNext ? '' : 'disabled'}>Next</button>
        </div>`;
}

function card(asset, isCache) {
    const id = assetId(asset);
    const cached = isCache || asset.cached || bridge.cachedById.has(id);
    const busy = bridge.busy.get(id);
    const error = bridge.errors[id] || '';
    const title = asset.name || (Array.isArray(asset.tags) ? asset.tags.slice(0, 3).join(', ') : 'Stock video');
    const thumb = asset.thumbnailUrl || '';
    const dims = asset.width && asset.height ? `${asset.width}×${asset.height}` : '';
    return `<article class="bridge-card${busy ? ' is-busy' : ''}" data-id="${escHtml(id)}">
        <div class="bridge-thumb">
            ${thumb ? `<img src="${escHtml(thumb)}" alt="" loading="lazy">` : '<span class="thumb-fallback">VIDEO</span>'}
            <span class="bridge-badges">${duration(asset.duration) ? `<b>${duration(asset.duration)}</b>` : ''}${dims ? `<b>${escHtml(dims)}</b>` : ''}</span>
            ${cached ? '<span class="cached-badge">CACHED</span>' : ''}
        </div>
        <div class="bridge-card-body">
            <strong title="${escHtml(title)}">${escHtml(title)}</strong>
            <div class="bridge-card-actions">
                <button type="button" class="primary" data-action="send">Send to Resolume</button>
            </div>
            ${busy ? `<div class="bridge-progress"><span></span><em>${escHtml(busy)}</em></div>` : ''}
            ${error ? `<div class="bridge-card-error">${escHtml(error)}</div>` : ''}
        </div>
    </article>`;
}

async function sendAsset(id) {
    if (bridge.busy.has(id)) return;
    const numeric = /^\d+$/.test(id) ? Number(id) : id;
    const layer = parseInt($('target-layer').value) || 1;
    const clip = $('target-clip').value;
    const connect = $('target-connect').checked;
    delete bridge.errors[id];
    bridge.busy.set(id, bridge.cachedById.has(id) ? 'Sending to Resolume…' : 'Caching, then sending…');
    render();
    try {
        const result = await jsonFetch('/api/bridge/send', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ assetId: numeric, rendition: 'medium', layer, clip, connect }),
        });
        toast(`Sent to layer ${result.layer}, slot ${result.clip}${result.connected ? ' — triggered' : ''}`);
        refreshResolume();
        refreshStockStatus();
        loadCache();
    } catch (e) {
        bridge.errors[id] = e.message;
        toast(`Send failed: ${e.message}`);
    } finally {
        bridge.busy.delete(id);
        render();
    }
}

// ------------------------------------------------------------
// Wiring
// ------------------------------------------------------------

document.addEventListener('DOMContentLoaded', () => {
    setupSettings();

    $('search-form').addEventListener('submit', (e) => {
        e.preventDefault();
        search($('search-input').value);
    });

    document.querySelectorAll('.bridge-mode').forEach(btn =>
        btn.addEventListener('click', () => { setMode(btn.dataset.mode); render(); }));

    $('target-layer').addEventListener('change', renderTargetBar);

    $('bridge-content').addEventListener('click', (e) => {
        const starter = e.target.closest('[data-starter]');
        if (starter) return search(starter.dataset.starter);
        const pager = e.target.closest('[data-page]');
        if (pager && !pager.disabled) return search(bridge.query, parseInt(pager.dataset.page));
        const action = e.target.closest('[data-action="send"]');
        if (action) {
            const holder = action.closest('[data-id]');
            if (holder) sendAsset(holder.dataset.id);
        }
    });

    refreshStockStatus();
    refreshResolume();
    loadCache();
    setInterval(refreshResolume, 10000);
});
