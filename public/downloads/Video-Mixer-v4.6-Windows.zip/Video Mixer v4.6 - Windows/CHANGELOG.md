# Video Mixer Changelog

Versioning: `vMAJOR.MINOR`
- **MAJOR** — paradigm shift, redesign, breaking changes
- **MINOR** — features, improvements, bug fixes

---

## v4.6 - 2026-10-03

Frame-perfect loops, full-frame deck previews, and a taller window.

### Changed
- **Loops cut on the frame instead of dissolving.** v4.4 removed the black
  frame at the loop point by blending the last 0.75 s of a clip into its
  first 0.75 s. On VJ loops authored to repeat, that superimposed two moments
  of the motion for over half a second every cycle, which reads as a hitch.
  The standby decoder now starts early by exactly its measured start-up
  latency, so its first frame lands as the active decoder's last frame ends,
  and the renderer cuts straight to it. Measured on a 1440p VJ loop, the loop
  point is now indistinguishable from mid-clip playback in both WebKit (the
  macOS app) and Chromium: no overlap, no black frame, and no held frame
  longer than normal playback. The start-up latency is learned on every loop,
  so it adapts to the machine, engine and clip resolution. Clips that were not
  made to loop now get a clean cut at the loop point.
- **Deck previews show the whole frame.** Previews used to fill the panel
  width and crop the top and bottom, so a wide, short preview showed only a
  strip. They now show the full clip at the panel's full height, centred. The
  mix preview and the projector output still fill the frame.
- **The app opens full height.** The macOS app now opens as tall as the
  screen allows, between the menu bar and the Dock, at the 1400 px width the
  console is designed around, centred.

## v4.5.1 - 2026-10-03

Hotfix. Stock search works on every Mac again.

### Fixed
- **The macOS app could not reach Pixabay on most Macs.** It looked for
  security certificates inside a python.org Python install, which only exists
  on machines that have one. Everywhere else every secure connection failed
  and the Stock tab said "Could not reach Pixabay." The app now uses the
  platform's certificates when they work, then the bundle macOS ships at
  `/etc/ssl/cert.pem`, then a copy built into the app. Respects an explicit
  `SSL_CERT_FILE` for proxies that need their own bundle.
- **A wrong Pixabay key looked like an outage.** Pixabay rejects bad keys with
  HTTP 400, which was not recognised, so the app said "Pixabay search is
  temporarily unavailable." It now says the key is invalid and that keys are
  case-sensitive.
- **The Stock error panel blamed the key for everything.** It offered "Change
  API key" for every failure, including network problems a key cannot fix. It
  now offers it only for key problems, and says plainly when a failure is a
  connection problem.
- Network failures are reported specifically: certificate check, DNS lookup,
  timeout, dropped connection, and a full or unwritable cache disk each get
  their own message. A dropped connection mid-download no longer surfaces as
  an internal error.
- `/api/stock/status` now reports which certificate source is in use
  (`tlsSource`), so this class of problem is visible immediately.

### Stock Bridge for Resolume 1.0.1
- Same Pixabay connection fix, via the shared stock provider.

## v4.5 — 2026-09-05

- Added a global Create a Slide composer with a live 16:9 preview, multiline
  text formatting, deck targeting, and separate Queue and Play actions.
- Added twelve infinitely looping Canvas2D backgrounds: solid, color field,
  split, bars, checker, grid, dots, rings, polygons, corners, frames, and
  diagonal lines.
- Added slide-specific colors, motion speed, hue, hue cycling, invert, and an
  opt-in strobe capped at 3 Hz with an in-app flashing-content warning.
- Made generated slides portable across playlists, saved sets, full sessions,
  clip pads and thumbnails, recording, Screenfolk Live, and the pop-out output.
- Synced generated-animation phase into the output window and preserved it
  across pause, resume, speed changes, and output-resolution changes.

## v4.4 — 2026-09-05

- Made video looping the default on both decks.
- Replaced end-of-clip teardown/reload with two preloaded decoders and a
  0.75-second eased self-crossfade, eliminating the black frame at the seam.
- Applied seamless looping consistently to deck previews, the master/program
  canvas, recordings, Screenfolk Live, and the independent output window.
- Kept the outgoing final frame visible if the standby decoder is late, and
  synchronized pause, seek, speed, volume, FX, and source cleanup across both
  decoder slots.

## v4.3 — 2026-09-04

- Added a one-use-code Screenfolk button that publishes the composed program
  canvas to one explicitly selected Screenfolk player over WebRTC.
- Kept the local mixer server bound to `127.0.0.1:5555`; the bridge makes
  outbound authenticated requests and does not expose local media files.
- Added automatic reconnect and clear live/offline status. Screenfolk owns the
  first-frame cutover and playlist fallback behavior.
- Program video only in this pilot. Audio is not transmitted.
- Rebuilt the macOS app bundle so the installed app contains the adapter.

## v4.2 — 2026-08-08

The Resolume release. A research pass over Resolume Arena/Avenue turned into
nine borrowed ideas for the mixer, plus a brand-new companion app that puts
the Stock browser workflow inside Resolume itself.

### Performance features
- **Clip Pads** — a new Pads tab on each deck with 8 trigger slots. Click to
  hot-swap the deck instantly (playlist untouched), Alt-click or click an
  empty pad to assign the current item, drag playlist or browser rows onto
  pads, right-click to clear. Pads persist with thumbnails between sessions
  and are included in saved session files.
- **MIDI mapping** — map any controller to the crossfader, deck transports,
  volumes, Auto Mix, Autopilot, tap tempo, record, quantize, and all 16 pads.
  MIDI button in the toolbar opens a learn-mode panel; mappings persist.
  Requires a Web MIDI browser (Chrome/Edge); the button hides elsewhere.
- **Quantize** — new button in BEAT SYNC. When armed, Auto Mix, pad triggers,
  and Autopilot transitions wait for the next beat on the tapped grid.
- **Audio-reactive FX** — AUDIO FX section pulses master brightness and/or
  saturation with the crossfade-weighted audio level (fast attack, slow
  decay). Deck analysers now run behind a zero-gain monitor so VU meters and
  audio FX read real signal without audible audio in the mixer window.
- **LFO** — animate master hue, brightness, or saturation with a sine,
  triangle, or square wave; free-running rate or synced to one bar of the
  tapped BPM.
- **Overlay layer** — logo image or text over the program feed with blend
  mode (Normal/Add/Screen/Multiply/Overlay/Difference), opacity, size, and
  five position presets. Renders above master FX in the mixer, mini preview,
  and output window.
- **Recording** — REC button in the toolbar captures the program output to a
  WebM file (video only; program audio lives in the output window). Timer on
  the button, R to toggle.
- **Hover scrub** — hover any video row (playlist, browser, pads) and sweep
  the mouse to scrub a floating preview, Resolume-style.
- **Note panel** and **playlist color tags** (right-click a row to cycle
  red/amber/green/blue).

### Control
- **REST control API** on both backends, modeled on Resolume's webserver:
  `GET /api/control` self-documents, `POST /api/control/<action>` queues
  commands (crossfader, automix, transition, deck transport, pads, autopilot,
  record, tap, fx), `GET /api/control/status` returns a live state snapshot.
  Local-machine only; foreign browser origins are rejected.

### Stock Bridge for Resolume (new companion app)
- `resolume_bridge.py` (zero dependencies, port 5566) reuses the same Pixabay
  provider and local cache as Video Mixer and injects clips straight into
  Resolume Arena/Avenue clip slots via the Resolume REST API
  (`POST /composition/layers/{n}/clips/{m}/open`).
- Live connection badge, layer picker fed from the composition, auto
  next-free-slot detection, optional trigger-after-send, and a settings
  drawer for host/port. Enable Resolume's webserver under Preferences.
- `run-resolume-bridge.command` launcher included.

### Keyboard
- `R` record, `G` quantize, `N` notes, `M` MIDI mapping.

---

## v4.1 — 2026-07-13

The product identity is now consistent from the performance console to the
operating-system launcher. A new dual-channel aperture mark represents Deck A
and Deck B converging at the mix point.

### Brand system
- Replaced the generic toolbar equalizer with the ELYWARE Video Mixer lockup.
- Added one vector source of truth plus generated macOS ICNS, Windows ICO,
  browser favicon, and Apple touch-icon assets.
- Added product-colored favicons and theme metadata to both mixer windows.

### Packaging
- The macOS app now uses the ELYWARE icon, the stable bundle identifier
  `net.elyware.videomixer`, and proper 4.1 version metadata.
- The Windows build now uses the matching multi-resolution application icon.
- Added a repeatable SVG-to-platform-icon generator for future brand updates.

## v4.0 — 2026-07-12

Real stock footage replaces the built-in visual sampler. Video Mixer now discovers royalty-free clips through Pixabay's supported video API and caches each selected clip locally before it can enter a live deck.

### Added
- **Stock browser** on both decks with concert, abstract, stage-light, and motion-background starter searches.
- **Pixabay API integration** through the local Python server; API keys stay out of browser storage, playlists, logs, and exported sessions.
- **Local performance cache** under `~/VideoMixer/cache/stock/media/`. Play and queue actions finish the download first, then use the same proven local-video pipeline as ordinary files.
- **Cached library view** for reusing downloaded clips without another API request or internet connection.
- Source, contributor, duration, resolution, cache status, and Pixabay Content License context in the browser.

### Reliability and safety
- Search responses are cached for 24 hours as required by Pixabay's API documentation.
- Media requests are resolved by numeric Pixabay asset ID on the server; the browser cannot submit arbitrary download URLs.
- Downloads use fixed provider filenames, size limits, HTTPS host checks, and atomic `.part` replacement so an interrupted transfer never appears as a playable file.
- The Stock tab has explicit setup, offline, empty, downloading, cached, and provider-error states.

### Compatibility
- Cached stock clips are normal local video playlist items, so existing deck playback, output-window sync, playlist reorder/copy/export, sessions, FX, and transitions continue to work unchanged.
- The v3 procedural engine remains loadable only for backward compatibility with older saved sessions; it is no longer exposed as the stock bank.

## v3.0 — 2026-07-12

Complete stock-visual reset. The elaborate 30-source bank has been replaced by twelve simple mixer primitives.

### Replaced
- Removed the Premium, High Contrast, Geometry, Ambient, Motion, Energy, and Retro visual collections from the browser.
- Added one deliberately ordered bank: White Field, Color Field, Hard Split, Bar Shift, Checker Shift, Line Grid, Dot Grid, Plain Rings, Polygon Loop, Corner Blocks, Frame Stack, and Diagonal Sweep.
- Removed category chips, search, PRO badges, sticky headings, and result-filter UI. The bank is now one larger sampler grid.

### Design rules
- Flat shapes only: no particles, glow, blur, noise, feedback, texture simulations, or per-pixel fields.
- Motion is slow and restrained; BPM response changes spacing, stroke, or scale without full-screen flashing.
- Every source uses fewer than 100 basic Canvas2D primitives and renders directly at output resolution.
- Old visual IDs resolve to sensible simple replacements so saved v2.x playlists continue to play.

---

## v2.2 — 2026-07-12

High-contrast geometric stock-bank expansion and visual-browser scaling pass.

### Added
- **Ten new mix-ready sources** — Binary Shift, Kinetic Bars, Moiré Orbit, Polar Blades, Radial Crown, Hex Reactor, Iso Stack, Signal Shards, Infinite Frames, and Bauhaus Sequencer.
- **High Contrast and Geometry collections** with monochrome negative space, restrained accent colors, deterministic motion, and BPM-driven spatial movement.
- **Visual category filters** for every bank section plus a PRO shortcut, live result counts, search clearing, keyboard tile activation, and a proper no-results state.

### Changed
- Visual-bank categories are now deliberately ordered for performance use: High Contrast, Geometry, Premium, then the legacy collections.
- Hard-edged geometric thumbnails use PNG encoding to preserve clean lines and prevent JPEG ringing.
- Heavy geometric sources can declare a maximum render rate independently of animation speed.
- Beat response changes geometry, scale, aperture, or stroke rather than using rapid full-screen luminance flashes.

### Performance
- Every new source is deterministic and avoids per-frame randomness.
- Dense hex, isometric, and shard renderers are capped at 30 fps while remaining smooth in the 60 fps mix engine.
- New thumbnails render a single selected frame rather than running the legacy 45-frame warm-up.

---

## v2.1 — 2026-07-12

Performance-console redesign, a curated premium visual pack, signature transition FX, and safer live playlist management.

### Added
- **Four premium live visuals** — Liquid Chrome, Velvet Caustics, Crystal Tunnel, and Topographic Flow. All are procedural, BPM-aware, and render without external stock-media files.
- **Three signature transition FX** — Prism Split, Fluid Wave, and Film Flash.
- **Playlist workspace tools** — per-item play/move/duplicate/remove controls, search, drag insertion feedback, cross-deck copy, and standalone set import/export.
- **Visual library search** with PRO badges and tags for the new curated pack.
- **In-app feedback toasts** for set management actions.

### Changed
- Rebuilt the interface as a modern performance console with clearer hierarchy, improved contrast, larger targets, richer deck identity, and compact responsive behavior.
- Generative visuals now follow the selected 720p/1080p program resolution instead of being permanently rendered at 480p/720p.
- Playlist/session exports omit temporary browser blob URLs that cannot survive a reload.

### Fixed
- Per-deck brightness, contrast, saturation, and hue now reach the master canvas and output window instead of appearing only in deck previews.
- Session settings restore even when a saved deck playlist is empty; playlist indices are clamped and imported items are validated.
- Rapid image cueing no longer allows stale load callbacks to overwrite the newest source.
- Queueing the first item no longer interrupts an ad-hoc visual already playing on that deck.
- Output canvases are no longer resized on every animation frame.

---

## v2.0 — 2026-07-12

Navigation redesign + Free Visuals Bank. Tabbed deck panels, real search, resizable layout, generative visuals, three-state theme.

### Added
- **Free Visuals Bank** — 16 built-in generative visuals, zero media files needed. Ambient (Color Wash, Aurora, Bokeh Drift, Lava Lamp, Ocean Waves), Motion (Starfield, Warp Tunnel, Neon Grid, Hypno Rays), Energy (Plasma, Strobe, Fireworks, Plexus), Retro (Matrix Rain, VHS Static, Kaleidoscope). Click to play, `+` to queue. BPM-reactive (tap tempo drives strobe, fireworks, tunnel pulse, starfield speed). Speed slider controls visual rate. Full output-window sync.
- **Tabbed deck panels** — Browse | Playlist | Visuals per deck. Playlist is now a first-class panel: item count badge, click-to-jump, per-item remove, clear, drag reorder.
- **Search bar per deck** — type to filter the current folder live, Enter runs a deep recursive search of subfolders (new `/api/search` endpoint, depth-limited, 400-result cap, 6s time budget, skips junk dirs). Result rows show relative paths. Load button becomes "Load N Results".
- **Queue buttons** — hover any file row or visual tile for a `+` that appends to the deck playlist without interrupting playback.
- **Resizable layout** — drag the bars between panels to resize deck/center widths, drag under the preview to resize preview height. Double-click a bar to reset, toolbar button resets everything. Layout persists.
- **Breadcrumb path** — every folder segment is clickable. Path input still accepts direct paths.
- **Recent folders menu** — last 10 browsed folders, shared across decks.
- **Transition filter** — search box above the transition picker.
- **Theme: Dark / Light / Auto** — Auto follows the system. Cycle via toolbar or `D`. Light palette rebuilt for contrast.
- **New shortcuts** — `[` / `]` focus Deck A / B search, `D` cycles theme.

### Changed
- Deck media pipeline unified: videos, images, and generative visuals are all playlist items. Slideshow auto-advance applies to visuals too.
- Web edition now uses a threading HTTP server — deep searches and media streaming no longer block each other.
- Static assets served no-cache with versioned URLs — upgrades apply instantly, no stale-JS breakage.
- Drag & drop uses the unified loader (object URLs handled by `loadItem`).

### Fixed
- Output window no longer freezes when the mixer window is hidden/backgrounded — mixer state now also broadcasts on a timer (rAF pauses in background tabs).
- Render health check is actually wired up at startup (was defined but never called in v1.1).
- Transition picker restores the active transition after session load and custom-transition reloads instead of resetting the highlight to Crossfade.

### Distributions
- `Video Mixer v2.0.zip` — Native macOS .app bundle, universal2 (Intel + Apple Silicon)
- `Video Mixer v2.0 - Web.zip` — Cross-platform Python web edition (zero deps)
- `Video Mixer v2.0 - Windows.zip` — Windows portable + .exe build script

---

## v1.1 — 2026-04-25

Stability pass + folder drag/drop + image-stay-on-screen default. Adopted the `vMAJOR.MINOR` versioning convention.

### Added
- **Folder drag & drop from Finder** — drop entire folders onto either deck, recursive scan for media, alphabetical natural sort
- **Drop overlay covers full deck panel** (not just the preview area)
- **Versioning system** — `vX.Y` shown in toolbar, on website, in distribution filenames
- **CHANGELOG.md** to track future releases

### Changed
- **Images stay on screen by default.** Slide slider defaults to OFF, range 0-30. Slideshow mode is opt-in (drag slider above 0).
- **Time display** for images shows just the counter when slideshow is OFF, full progress bar when ON.

### Fixed (stability)
- Object URLs from drag/drop are tracked per deck and revoked when loading a new playlist. No more memory leaks from blob refs.
- Custom transition `<script>` tags are removed before reload. No more pile-up.
- Auto-save no longer writes blob URLs to localStorage.
- AudioContext auto-resumes on focus / visibility change. Survives Chrome's auto-suspend after inactivity.
- Render loop has a stall-detection health check.
- Error retry capped at 5 — playlist won't infinite-loop on broken media.
- Image fade chain releases stale references after fade completes.
- Periodic 30s AudioContext resume guard.

### Distributions
- `Video Mixer v1.1.zip` — Native macOS .app bundle, **universal2** (Intel + Apple Silicon)
- `Video Mixer v1.1 - Web.zip` — Cross-platform Python web edition (zero deps)
- `Video Mixer v1.1 - Windows.zip` — Windows portable + .exe build script

### Build notes
- The Mac .app is built as a universal2 binary. PyInstaller `--target-arch universal2` requires every linked C extension to be a fat binary; we excluded `cffi`, `cryptography`, `numpy`, `pandas`, `PIL`, `pygame`, `pydantic_core`, `rpds`, `matplotlib`, `scipy`, `tkinter` from the bundle since none are used. `markupsafe` was reinstalled with its universal2 wheel.

---

## v1.0 — 2026-04 (initial baseline)

The pre-numbered baseline. Original feature set before the stability + UX pass.

### Features
- Dual deck interface with folder browsing
- 22+ built-in transitions (crossfade, wipes, iris, pixelate, dissolves)
- Dual monitor output via second window with BroadcastChannel sync
- Autopilot mode with configurable hold/transition timing
- VU meters with audio level visualization on each deck
- Save / Load session as JSON
- BPM tap tempo + beat sync (auto-mix on the 4)
- Per-deck FX (brightness, contrast, saturation, hue) with collapsible panel
- Master FX applied to the mix bus
- Custom transitions: drop `.js` files into `~/VideoMixer/transitions/`
- Light / Dark theme toggle
- Auto-save session to localStorage
- Crossfader dead zones at 0/1000 for clean cuts
- Output window audio passthrough with crossfader-aware volume
- Playlist drag-to-reorder
- Fullscreen mode
- Keyboard shortcuts: Q/W play, A/S/K/L next/prev, T tap tempo, P autopilot, etc.
