Stock Bridge for Resolume
=========================
Enable Resolume Preferences > Webserver, then run:
    python resolume_bridge.py
Opens at http://127.0.0.1:5566
