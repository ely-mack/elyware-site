# Screenfolk live output

Version 4.3 includes the Screenfolk live-output pilot in both the source
launchers and the rebuilt macOS `Video Mixer.app`.

1. In the Screenfolk dashboard, open the exact landscape player.
2. Choose **Live mixer** and create a one-time code.
3. In ELYWARE Video Mixer, choose **Screenfolk**, enter the code, and connect.
4. Wait for both the mixer to show **LIVE** and the intended physical display
   to show the program mix.
5. Choose **Stop** in either application to return to the player's playlist.

The program feed is video-only in this pilot. The local Python server remains
loopback-only. The one-time code is bound to a random in-memory request
identifier so an interrupted connection can be retried only by this mixer
process. Neither the session token nor that identifier is written to disk. Keep
the mixer window visible for full frame rate;
background rendering stays active at a reduced rate only during a live output
and may be browser-throttled. A lost Screenfolk control connection stops local
publication after 20 seconds so the player can remain safely on its playlist.
