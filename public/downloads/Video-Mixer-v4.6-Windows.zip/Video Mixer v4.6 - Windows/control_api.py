"""Local REST control surface for Video Mixer.

Lets external tools on this machine (Stream Deck plugins, scripts, the
Resolume bridge) drive the mixer the way Resolume's webserver exposes its
composition. The mixer page polls for queued commands and posts state
snapshots; external clients enqueue commands and read the latest snapshot.

Stdlib only, shared by video_mixer.py (Flask) and video_mixer_web.py.
"""

from __future__ import annotations

import threading
import time

# Commands the browser knows how to dispatch. Anything else is rejected so a
# typo'd action fails loudly at the HTTP layer instead of silently queueing.
ALLOWED_ACTIONS = frozenset({
    'crossfader',    # {"value": 0..1}
    'automix',       # {"duration": ms} (optional)
    'transition',    # {"id": "crossfade"}
    'deck',          # {"deck": "a"|"b", "op": "play|pause|toggle|next|prev|volume|speed", "value": n}
    'pad',           # {"deck": "a"|"b", "index": 0..7}
    'autopilot',     # {"on": true|false} (omit = toggle)
    'record',        # {"on": true|false} (omit = toggle)
    'tap',           # {} tap tempo
    'fx',            # {"key": "brightness|contrast|saturate|hue", "value": n}
})

MAX_QUEUE = 64
MAX_BODY_BYTES = 4096


class ControlBus:
    """Thread-safe command queue + last-known mixer state."""

    def __init__(self):
        self._lock = threading.Lock()
        self._queue = []
        self._next_id = 1
        self._state = None
        self._state_time = 0.0

    def enqueue(self, action, args):
        if action not in ALLOWED_ACTIONS:
            return None
        if not isinstance(args, dict):
            args = {}
        with self._lock:
            if len(self._queue) >= MAX_QUEUE:
                self._queue.pop(0)
            cmd = {'id': self._next_id, 'action': action, 'args': args, 'ts': time.time()}
            self._next_id += 1
            self._queue.append(cmd)
            return cmd['id']

    def drain(self):
        """Return and clear all queued commands (single consumer: the mixer page)."""
        with self._lock:
            queue, self._queue = self._queue, []
            return queue

    def set_state(self, state):
        if not isinstance(state, dict):
            return False
        with self._lock:
            self._state = state
            self._state_time = time.time()
        return True

    def status(self):
        with self._lock:
            age = time.time() - self._state_time if self._state is not None else None
            return {
                'connected': age is not None and age < 5.0,
                'stateAge': round(age, 2) if age is not None else None,
                'pendingCommands': len(self._queue),
                'state': self._state,
            }


control_bus = ControlBus()


def control_help():
    """Self-describing index served at GET /api/control."""
    return {
        'service': 'video-mixer-control',
        'usage': 'POST /api/control/<action> with a JSON args body. '
                 'GET /api/control/status for the latest mixer state.',
        'actions': sorted(ALLOWED_ACTIONS),
        'examples': [
            {'method': 'POST', 'path': '/api/control/crossfader', 'body': {'value': 0.5}},
            {'method': 'POST', 'path': '/api/control/automix', 'body': {'duration': 2000}},
            {'method': 'POST', 'path': '/api/control/deck', 'body': {'deck': 'a', 'op': 'play'}},
            {'method': 'POST', 'path': '/api/control/pad', 'body': {'deck': 'b', 'index': 0}},
        ],
    }
