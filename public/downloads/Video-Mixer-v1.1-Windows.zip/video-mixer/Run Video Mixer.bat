@echo off
title Video Mixer
echo.
echo   ====================================
echo      VIDEO MIXER - Web Edition
echo   ====================================
echo.
echo   Starting Video Mixer...
echo   Your browser will open automatically.
echo   Keep this window open while using the app.
echo   Press Ctrl+C to quit.
echo.
python "%~dp0video_mixer_web.py"
if errorlevel 1 (
    echo.
    echo   ERROR: Python 3 is required but was not found.
    echo   Download it from https://www.python.org/downloads/
    echo   Make sure to check "Add Python to PATH" during install.
    echo.
    pause
)
