#!/usr/bin/env python3
"""
Video Mixer v1.1 — Web Edition (Zero Dependencies)
Runs on any system with Python 3. No pip install needed.
Works on Mac, Windows, and Linux.
"""

VERSION = "1.1"

import os
import sys
import json
import glob
import mimetypes
import threading
import webbrowser
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote

PORT = 5555
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MEDIA_EXTENSIONS = {
    'video': {'.mp4', '.mov', '.webm', '.m4v', '.ogv', '.mkv'},
    'image': {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.tiff', '.tif'},
}
ALL_MEDIA = MEDIA_EXTENSIONS['video'] | MEDIA_EXTENSIONS['image']
TRANSITIONS_DIR = os.path.expanduser('~/VideoMixer/transitions')

MIME_MAP = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
    '.svg': 'image/svg+xml',
    '.mp4': 'video/mp4',
    '.mov': 'video/quicktime',
    '.webm': 'video/webm',
    '.m4v': 'video/mp4',
    '.ogv': 'video/ogg',
    '.mkv': 'video/x-matroska',
    '.bmp': 'image/bmp',
    '.tiff': 'image/tiff',
    '.tif': 'image/tiff',
}


def read_template(name):
    """Read an HTML template and return its contents."""
    path = os.path.join(BASE_DIR, 'templates', name)
    with open(path, 'r') as f:
        return f.read()


class MixerHandler(BaseHTTPRequestHandler):
    """Handle all Video Mixer HTTP requests."""

    def log_message(self, format, *args):
        """Suppress default request logging."""
        pass

    def send_json(self, data, status=200):
        body = json.dumps(data).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', len(body))
        self.end_headers()
        self.wfile.write(body)

    def send_html(self, html):
        body = html.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', len(body))
        self.end_headers()
        self.wfile.write(body)

    def send_error_json(self, status, message):
        self.send_json({'error': message}, status)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)

        # Routes
        if path == '/':
            self.send_html(read_template('index.html'))
        elif path == '/output':
            self.send_html(read_template('output.html'))
        elif path.startswith('/static/'):
            self.serve_static(path)
        elif path == '/api/browse':
            self.api_browse(params)
        elif path == '/api/media':
            self.api_media(params)
        elif path == '/api/home':
            self.send_json({'path': str(Path.home())})
        elif path == '/api/transitions':
            self.api_transitions()
        elif path.startswith('/api/transitions/'):
            name = path.split('/api/transitions/')[-1]
            self.api_serve_transition(name)
        else:
            self.send_error(404, 'Not Found')

    def serve_static(self, path):
        """Serve files from the static/ directory."""
        # Remove /static/ prefix and sanitize
        rel_path = path[len('/static/'):]
        full_path = os.path.normpath(os.path.join(BASE_DIR, 'static', rel_path))

        # Security: ensure the path is within static/
        if not full_path.startswith(os.path.join(BASE_DIR, 'static')):
            self.send_error(403, 'Forbidden')
            return

        if not os.path.isfile(full_path):
            self.send_error(404, 'Not Found')
            return

        ext = os.path.splitext(full_path)[1].lower()
        mime = MIME_MAP.get(ext, 'application/octet-stream')

        with open(full_path, 'rb') as f:
            data = f.read()

        self.send_response(200)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', len(data))
        self.send_header('Cache-Control', 'public, max-age=3600')
        self.end_headers()
        self.wfile.write(data)

    def api_browse(self, params):
        """List directories and media files at a given path."""
        browse_path = params.get('path', [str(Path.home())])[0]
        browse_path = os.path.expanduser(browse_path)

        if not os.path.isdir(browse_path):
            self.send_error_json(400, 'Not a valid directory')
            return

        dirs = []
        files = []

        try:
            entries = sorted(os.listdir(browse_path), key=str.lower)
        except PermissionError:
            self.send_error_json(403, 'Permission denied')
            return

        for entry in entries:
            if entry.startswith('.'):
                continue
            full = os.path.join(browse_path, entry)
            if os.path.isdir(full):
                dirs.append({'name': entry, 'path': full})
            elif os.path.isfile(full):
                ext = os.path.splitext(entry)[1].lower()
                if ext in ALL_MEDIA:
                    media_type = 'video' if ext in MEDIA_EXTENSIONS['video'] else 'image'
                    files.append({
                        'name': entry,
                        'path': full,
                        'type': media_type,
                        'ext': ext,
                    })

        self.send_json({
            'current': browse_path,
            'parent': str(Path(browse_path).parent),
            'dirs': dirs,
            'files': files,
        })

    def api_media(self, params):
        """Serve a media file with range support."""
        file_path = params.get('path', [''])[0]
        if not file_path or not os.path.isfile(file_path):
            self.send_error(404, 'Not Found')
            return

        ext = os.path.splitext(file_path)[1].lower()
        if ext not in ALL_MEDIA:
            self.send_error(403, 'Forbidden')
            return

        mime = MIME_MAP.get(ext)
        if not mime:
            mime = mimetypes.guess_type(file_path)[0] or 'application/octet-stream'

        file_size = os.path.getsize(file_path)

        # Handle Range requests for video seeking
        range_header = self.headers.get('Range')
        if range_header and range_header.startswith('bytes='):
            ranges = range_header[6:].split('-')
            start = int(ranges[0]) if ranges[0] else 0
            end = int(ranges[1]) if ranges[1] else file_size - 1
            end = min(end, file_size - 1)
            length = end - start + 1

            self.send_response(206)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', length)
            self.send_header('Content-Range', f'bytes {start}-{end}/{file_size}')
            self.send_header('Accept-Ranges', 'bytes')
            self.end_headers()

            with open(file_path, 'rb') as f:
                f.seek(start)
                remaining = length
                while remaining > 0:
                    chunk = f.read(min(65536, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)
        else:
            self.send_response(200)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', file_size)
            self.send_header('Accept-Ranges', 'bytes')
            self.end_headers()

            with open(file_path, 'rb') as f:
                while True:
                    chunk = f.read(65536)
                    if not chunk:
                        break
                    self.wfile.write(chunk)

    def api_transitions(self):
        """List custom transition JS files."""
        if not os.path.isdir(TRANSITIONS_DIR):
            self.send_json({'transitions': []})
            return

        files = glob.glob(os.path.join(TRANSITIONS_DIR, '*.js'))
        transitions = []
        for f in sorted(files):
            name = os.path.splitext(os.path.basename(f))[0]
            transitions.append({'name': name, 'path': f})
        self.send_json({'transitions': transitions})

    def api_serve_transition(self, name):
        """Serve a custom transition JS file."""
        safe_name = os.path.basename(name)
        path = os.path.join(TRANSITIONS_DIR, safe_name + '.js')
        if not os.path.isfile(path):
            self.send_error(404, 'Not Found')
            return

        with open(path, 'rb') as f:
            data = f.read()

        self.send_response(200)
        self.send_header('Content-Type', 'application/javascript')
        self.send_header('Content-Length', len(data))
        self.end_headers()
        self.wfile.write(data)


def main():
    os.makedirs(TRANSITIONS_DIR, exist_ok=True)

    server = HTTPServer(('127.0.0.1', PORT), MixerHandler)

    print()
    print('  ====================================')
    print(f'     VIDEO MIXER v{VERSION} — Web Edition')
    print('  ====================================')
    print(f'  Running at http://127.0.0.1:{PORT}')
    print('  Custom transitions: ~/VideoMixer/transitions/')
    print()
    print('  Press Ctrl+C to quit.')
    print()

    # Open browser after a short delay
    threading.Timer(1.0, lambda: webbrowser.open(f'http://127.0.0.1:{PORT}')).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\n  Shutting down...')
        server.shutdown()


if __name__ == '__main__':
    main()
