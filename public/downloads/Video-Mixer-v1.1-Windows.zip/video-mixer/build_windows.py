#!/usr/bin/env python3
"""
Build Video Mixer as a standalone Windows .exe using PyInstaller.

Usage (run on a Windows machine with Python 3 installed):
    pip install pyinstaller
    python build_windows.py

Output:
    dist/Video Mixer/Video Mixer.exe
"""

import subprocess
import sys
import os

APP_NAME = "Video Mixer"
ENTRY = "video_mixer_web.py"

# Data files to bundle (src:dst uses ; on Windows)
DATA_FILES = [
    ("templates", "templates"),
    ("static", "static"),
]


def build():
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--name", APP_NAME,
        "--onedir",
        "--noconfirm",
        "--clean",
        "--console",            # Show console window (user sees server status)
        "--icon", "NONE",       # No custom icon yet
    ]

    # Add data files — Windows uses ; as separator
    sep = ";" if sys.platform == "win32" else ":"
    for src, dst in DATA_FILES:
        cmd.extend(["--add-data", f"{src}{sep}{dst}"])

    cmd.append(ENTRY)

    print(f"\n  Building {APP_NAME}.exe ...\n")
    print(f"  Command: {' '.join(cmd)}\n")

    result = subprocess.run(cmd, cwd=os.path.dirname(os.path.abspath(__file__)))

    if result.returncode == 0:
        print(f"\n  Build successful!")
        print(f"  App location: dist/{APP_NAME}/{APP_NAME}.exe")
        print(f"\n  To distribute, zip the entire 'dist/{APP_NAME}' folder.\n")
    else:
        print(f"\n  Build failed with exit code {result.returncode}\n")
        sys.exit(1)


if __name__ == "__main__":
    build()
