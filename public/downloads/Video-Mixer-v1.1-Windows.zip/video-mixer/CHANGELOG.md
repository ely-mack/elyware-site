# Video Mixer Changelog

Versioning: `vMAJOR.MINOR`
- **MAJOR** — paradigm shift, redesign, breaking changes
- **MINOR** — features, improvements, bug fixes

---

## v1.1 — 2026-04-25

Stability pass + folder drag/drop + image-stay-on-screen default. Adopted the `vMAJOR.MINOR` versioning convention.

### Added
- **Folder drag & drop from Finder** — drop entire folders onto either deck, recursive scan for media, alphabetical natural sort
- **Drop overlay covers full deck panel** (not just the preview area)
- **Versioning system** — `vX.Y` shown in toolbar, on website, in distribution filenames
- **CHANGELOG.md** to track future releases

### Changed
- **Images stay on screen by default.** Slide slider defaults to OFF, range 0-30. Slideshow mode is opt-in (drag slider above 0).
- **Time display** for images shows just the counter when slideshow is OFF, full progress bar when ON.

### Fixed (stability)
- Object URLs from drag/drop are tracked per deck and revoked when loading a new playlist. No more memory leaks from blob refs.
- Custom transition `<script>` tags are removed before reload. No more pile-up.
- Auto-save no longer writes blob URLs to localStorage.
- AudioContext auto-resumes on focus / visibility change. Survives Chrome's auto-suspend after inactivity.
- Render loop has a stall-detection health check.
- Error retry capped at 5 — playlist won't infinite-loop on broken media.
- Image fade chain releases stale references after fade completes.
- Periodic 30s AudioContext resume guard.

### Distributions
- `Video Mixer v1.1.zip` — Native macOS .app bundle (Apple Silicon)
- `Video Mixer v1.1 - Web.zip` — Cross-platform Python web edition (zero deps)
- `Video Mixer v1.1 - Windows.zip` — Windows portable + .exe build script

---

## v1.0 — 2026-04 (initial baseline)

The pre-numbered baseline. Original feature set before the stability + UX pass.

### Features
- Dual deck interface with folder browsing
- 22+ built-in transitions (crossfade, wipes, iris, pixelate, dissolves)
- Dual monitor output via second window with BroadcastChannel sync
- Autopilot mode with configurable hold/transition timing
- VU meters with audio level visualization on each deck
- Save / Load session as JSON
- BPM tap tempo + beat sync (auto-mix on the 4)
- Per-deck FX (brightness, contrast, saturation, hue) with collapsible panel
- Master FX applied to the mix bus
- Custom transitions: drop `.js` files into `~/VideoMixer/transitions/`
- Light / Dark theme toggle
- Auto-save session to localStorage
- Crossfader dead zones at 0/1000 for clean cuts
- Output window audio passthrough with crossfader-aware volume
- Playlist drag-to-reorder
- Fullscreen mode
- Keyboard shortcuts: Q/W play, A/S/K/L next/prev, T tap tempo, P autopilot, etc.
