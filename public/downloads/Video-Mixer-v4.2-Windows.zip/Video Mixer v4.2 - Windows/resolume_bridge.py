#!/usr/bin/env python3
"""
ELYWARE Stock Bridge for Resolume v1.0
Searches Pixabay, caches clips locally (same cache as Video Mixer), and
injects them into Resolume Arena/Avenue clip slots over the Resolume
REST API (Preferences > Webserver must be enabled, default port 8080).

Zero dependencies — runs on any system with Python 3.
"""

VERSION = "1.0"

import json
import os
import re
import sys
import threading
import webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse, parse_qs
from urllib.request import Request, urlopen

from stock_provider import StockProviderError, stock_provider, validate_local_origin

PORT = 5566
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = Path.home() / "VideoMixer" / "config.json"

DEFAULT_RESOLUME = {"host": "127.0.0.1", "port": 8080}
HOST_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,253}$")
RESOLUME_TIMEOUT = 4

MIME_MAP = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.png': 'image/png',
    '.svg': 'image/svg+xml',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
}


def read_config():
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
        if not isinstance(data, dict):
            return {}
        return data
    except (OSError, ValueError):
        return {}


def write_config(updates):
    data = read_config()
    data.update(updates)
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = CONFIG_PATH.with_name(f".{CONFIG_PATH.name}.{os.getpid()}.tmp")
    try:
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(data, handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, CONFIG_PATH)
        os.chmod(CONFIG_PATH, 0o600)
    finally:
        try:
            tmp.unlink()
        except FileNotFoundError:
            pass


def resolume_target():
    data = read_config()
    host = str(data.get('resolumeHost') or DEFAULT_RESOLUME['host'])
    try:
        port = int(data.get('resolumePort') or DEFAULT_RESOLUME['port'])
    except (TypeError, ValueError):
        port = DEFAULT_RESOLUME['port']
    if not HOST_RE.fullmatch(host):
        host = DEFAULT_RESOLUME['host']
    if not 1 <= port <= 65535:
        port = DEFAULT_RESOLUME['port']
    return host, port


class ResolumeError(Exception):
    def __init__(self, message, status=502):
        super().__init__(message)
        self.message = message
        self.status = status


def resolume_request(path, method='GET', body=None, content_type=None):
    host, port = resolume_target()
    url = f'http://{host}:{port}/api/v1{path}'
    headers = {'Accept': 'application/json'}
    data = None
    if body is not None:
        data = body if isinstance(body, bytes) else str(body).encode('utf-8')
        headers['Content-Type'] = content_type or 'text/plain'
    request = Request(url, data=data, headers=headers, method=method)
    try:
        with urlopen(request, timeout=RESOLUME_TIMEOUT) as response:
            raw = response.read(8 * 1024 * 1024)
    except HTTPError as exc:
        detail = ''
        try:
            detail = exc.read(500).decode('utf-8', 'replace')
        except OSError:
            pass
        raise ResolumeError(f'Resolume rejected the request ({exc.code}). {detail}'.strip(), 502) from None
    except (URLError, TimeoutError, OSError):
        raise ResolumeError(
            f'Could not reach Resolume at {host}:{port}. '
            'Is Arena/Avenue running with the webserver enabled?', 503) from None
    if not raw:
        return None
    try:
        return json.loads(raw.decode('utf-8'))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None


def _param_value(obj):
    """Resolume wraps parameters as {'value': ...}; unwrap safely."""
    if isinstance(obj, dict):
        return obj.get('value')
    return obj


def _clip_is_empty(clip):
    """Best-effort empty-slot detection on a composition clip entry."""
    if not isinstance(clip, dict):
        return True
    video = clip.get('video')
    audio = clip.get('audio')
    has_video = isinstance(video, dict) and (video.get('fileinfo') or video.get('description') or video.get('sourceparams') or video.get('effects'))
    has_audio = isinstance(audio, dict) and (audio.get('fileinfo') or audio.get('description'))
    name = _param_value(clip.get('name')) or ''
    return not has_video and not has_audio and not name


def resolume_summary():
    """Connection status + a compact layer map for the UI."""
    try:
        product = resolume_request('/product')
    except ResolumeError as exc:
        host, port = resolume_target()
        return {'connected': False, 'error': exc.message, 'host': host, 'port': port}
    composition = None
    try:
        composition = resolume_request('/composition')
    except ResolumeError:
        pass
    layers = []
    if isinstance(composition, dict):
        for i, layer in enumerate(composition.get('layers') or [], start=1):
            if not isinstance(layer, dict):
                continue
            clips = layer.get('clips') or []
            free = None
            for j, clip in enumerate(clips, start=1):
                if _clip_is_empty(clip):
                    free = j
                    break
            layers.append({
                'index': i,
                'name': _param_value(layer.get('name')) or f'Layer {i}',
                'clipCount': len(clips),
                'freeClip': free,
            })
    host, port = resolume_target()
    name = 'Resolume'
    version = ''
    if isinstance(product, dict):
        name = product.get('name') or name
        version = '.'.join(str(product.get(k)) for k in ('major', 'minor', 'micro')
                           if product.get(k) is not None)
    return {
        'connected': True,
        'product': name,
        'version': version,
        'host': host,
        'port': port,
        'layers': layers,
    }


def send_to_resolume(asset_id, rendition, layer, clip, connect):
    """Cache the Pixabay asset locally, then open it in a Resolume clip slot."""
    cached = stock_provider.cache_asset('pixabay', asset_id, rendition)
    item = cached.get('item') or {}
    path = item.get('path')
    if not path or not os.path.isfile(path):
        raise ResolumeError('Cached file is missing', 500)

    layer = int(layer)
    if not 1 <= layer <= 99:
        raise ResolumeError('Layer must be between 1 and 99', 400)

    if clip in (None, '', 'auto'):
        summary = resolume_summary()
        if not summary.get('connected'):
            raise ResolumeError(summary.get('error') or 'Resolume is not reachable', 503)
        match = next((l for l in summary.get('layers', []) if l['index'] == layer), None)
        if match is None:
            raise ResolumeError(f'Layer {layer} was not found in the composition', 400)
        clip = match.get('freeClip') or match.get('clipCount') or 1
    clip = int(clip)
    if not 1 <= clip <= 999:
        raise ResolumeError('Clip must be between 1 and 999', 400)

    file_uri = Path(path).resolve().as_uri()
    resolume_request(f'/composition/layers/{layer}/clips/{clip}/open', method='POST', body=file_uri)
    if connect:
        resolume_request(f'/composition/layers/{layer}/clips/{clip}/connect', method='POST', body='')
    return {'ok': True, 'layer': layer, 'clip': clip, 'file': path, 'item': item, 'connected': bool(connect)}


class BridgeHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def send_json(self, data, status=200):
        body = json.dumps(data).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', len(body))
        self.end_headers()
        self.wfile.write(body)

    def send_html(self, html):
        body = html.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', len(body))
        self.end_headers()
        self.wfile.write(body)

    def send_stock_error(self, error):
        if isinstance(error, StockProviderError):
            self.send_json(error.payload(), error.status)
        elif isinstance(error, ResolumeError):
            self.send_json({'error': {'code': 'resolume_error', 'message': error.message}}, error.status)
        else:
            self.send_json({'error': {
                'code': 'bridge_internal_error',
                'message': 'Bridge request failed.',
            }}, 500)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        params = parse_qs(parsed.query)

        if path == '/':
            with open(os.path.join(BASE_DIR, 'templates', 'bridge.html'), 'r') as f:
                self.send_html(f.read())
        elif path.startswith('/static/'):
            self.serve_static(path)
        elif path == '/api/stock/status':
            self.send_json(stock_provider.status())
        elif path == '/api/stock/search':
            try:
                self.send_json(stock_provider.search(
                    params.get('q', [''])[0],
                    params.get('page', [1])[0],
                    params.get('order', ['popular'])[0],
                ))
            except Exception as error:
                self.send_stock_error(error)
        elif path == '/api/stock/cache':
            self.send_json(stock_provider.list_cached())
        elif path == '/api/bridge/config':
            host, port = resolume_target()
            self.send_json({'host': host, 'port': port})
        elif path == '/api/bridge/status':
            self.send_json(resolume_summary())
        else:
            self.send_error(404, 'Not Found')

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path not in {'/api/stock/cache', '/api/stock/config',
                               '/api/bridge/config', '/api/bridge/send'}:
            self.send_error(404, 'Not Found')
            return
        if not validate_local_origin(
                self.headers.get('Origin'), self.headers.get('Host'), PORT):
            self.send_json({'error': {
                'code': 'forbidden_origin',
                'message': 'Bridge mutations must come from the local UI.',
            }}, 403)
            return
        content_type = self.headers.get('Content-Type', '').split(';', 1)[0].strip().lower()
        if content_type != 'application/json':
            self.send_json({'error': {
                'code': 'invalid_content_type',
                'message': 'Expected an application/json request body.',
            }}, 415)
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            length = -1
        if length < 0 or length > 4096:
            self.send_json({'error': {
                'code': 'invalid_request_size',
                'message': 'Request body is invalid or too large.',
            }}, 413)
            return
        try:
            payload = json.loads(self.rfile.read(length).decode('utf-8'))
        except (UnicodeDecodeError, json.JSONDecodeError):
            payload = None
        if not isinstance(payload, dict):
            self.send_json({'error': {
                'code': 'invalid_json',
                'message': 'Expected a JSON object.',
            }}, 400)
            return
        try:
            if parsed.path == '/api/stock/config':
                self.send_json(stock_provider.configure(payload.get('apiKey')))
            elif parsed.path == '/api/stock/cache':
                self.send_json(stock_provider.cache_asset(
                    payload.get('provider'),
                    payload.get('assetId'),
                    payload.get('rendition', 'medium'),
                ))
            elif parsed.path == '/api/bridge/config':
                host = str(payload.get('host') or '').strip()
                try:
                    port = int(payload.get('port') or 0)
                except (TypeError, ValueError):
                    port = 0
                if not HOST_RE.fullmatch(host):
                    self.send_json({'error': {
                        'code': 'invalid_host',
                        'message': 'Host may contain letters, digits, dots, dashes, and colons only.',
                    }}, 400)
                    return
                if not 1 <= port <= 65535:
                    self.send_json({'error': {
                        'code': 'invalid_port',
                        'message': 'Port must be between 1 and 65535.',
                    }}, 400)
                    return
                write_config({'resolumeHost': host, 'resolumePort': port})
                self.send_json({'ok': True, 'host': host, 'port': port})
            else:
                self.send_json(send_to_resolume(
                    payload.get('assetId'),
                    payload.get('rendition', 'medium'),
                    payload.get('layer', 1),
                    payload.get('clip', 'auto'),
                    bool(payload.get('connect')),
                ))
        except (StockProviderError, ResolumeError) as error:
            self.send_stock_error(error)
        except (TypeError, ValueError):
            self.send_json({'error': {
                'code': 'invalid_request',
                'message': 'Layer and clip must be numbers.',
            }}, 400)
        except Exception:
            self.send_stock_error(None)

    def serve_static(self, path):
        rel_path = path[len('/static/'):].split('?', 1)[0]
        full_path = os.path.normpath(os.path.join(BASE_DIR, 'static', rel_path))
        if not full_path.startswith(os.path.join(BASE_DIR, 'static')):
            self.send_error(403, 'Forbidden')
            return
        if not os.path.isfile(full_path):
            self.send_error(404, 'Not Found')
            return
        ext = os.path.splitext(full_path)[1].lower()
        with open(full_path, 'rb') as f:
            data = f.read()
        self.send_response(200)
        self.send_header('Content-Type', MIME_MAP.get(ext, 'application/octet-stream'))
        self.send_header('Content-Length', len(data))
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        self.wfile.write(data)


def main():
    server = ThreadingHTTPServer(('127.0.0.1', PORT), BridgeHandler)
    host, rport = resolume_target()
    print()
    print('  ==========================================')
    print(f'     STOCK BRIDGE FOR RESOLUME v{VERSION}')
    print('  ==========================================')
    print(f'  Bridge UI:  http://127.0.0.1:{PORT}')
    print(f'  Resolume:   {host}:{rport} (REST API)')
    print()
    print('  In Resolume: Preferences > Webserver > enable.')
    print('  Press Ctrl+C to quit.')
    print()
    if '--no-browser' not in sys.argv:
        threading.Timer(1.0, lambda: webbrowser.open(f'http://127.0.0.1:{PORT}')).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\n  Shutting down...')
        server.shutdown()


if __name__ == '__main__':
    main()
