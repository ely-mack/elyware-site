# Video Mixer Changelog

Versioning: `vMAJOR.MINOR`
- **MAJOR** — paradigm shift, redesign, breaking changes
- **MINOR** — features, improvements, bug fixes

---

## v4.0 — 2026-07-12

Real stock footage replaces the built-in visual sampler. Video Mixer now discovers royalty-free clips through Pixabay's supported video API and caches each selected clip locally before it can enter a live deck.

### Added
- **Stock browser** on both decks with concert, abstract, stage-light, and motion-background starter searches.
- **Pixabay API integration** through the local Python server; API keys stay out of browser storage, playlists, logs, and exported sessions.
- **Local performance cache** under `~/VideoMixer/cache/stock/media/`. Play and queue actions finish the download first, then use the same proven local-video pipeline as ordinary files.
- **Cached library view** for reusing downloaded clips without another API request or internet connection.
- Source, contributor, duration, resolution, cache status, and Pixabay Content License context in the browser.

### Reliability and safety
- Search responses are cached for 24 hours as required by Pixabay's API documentation.
- Media requests are resolved by numeric Pixabay asset ID on the server; the browser cannot submit arbitrary download URLs.
- Downloads use fixed provider filenames, size limits, HTTPS host checks, and atomic `.part` replacement so an interrupted transfer never appears as a playable file.
- The Stock tab has explicit setup, offline, empty, downloading, cached, and provider-error states.

### Compatibility
- Cached stock clips are normal local video playlist items, so existing deck playback, output-window sync, playlist reorder/copy/export, sessions, FX, and transitions continue to work unchanged.
- The v3 procedural engine remains loadable only for backward compatibility with older saved sessions; it is no longer exposed as the stock bank.

## v3.0 — 2026-07-12

Complete stock-visual reset. The elaborate 30-source bank has been replaced by twelve simple mixer primitives.

### Replaced
- Removed the Premium, High Contrast, Geometry, Ambient, Motion, Energy, and Retro visual collections from the browser.
- Added one deliberately ordered bank: White Field, Color Field, Hard Split, Bar Shift, Checker Shift, Line Grid, Dot Grid, Plain Rings, Polygon Loop, Corner Blocks, Frame Stack, and Diagonal Sweep.
- Removed category chips, search, PRO badges, sticky headings, and result-filter UI. The bank is now one larger sampler grid.

### Design rules
- Flat shapes only: no particles, glow, blur, noise, feedback, texture simulations, or per-pixel fields.
- Motion is slow and restrained; BPM response changes spacing, stroke, or scale without full-screen flashing.
- Every source uses fewer than 100 basic Canvas2D primitives and renders directly at output resolution.
- Old visual IDs resolve to sensible simple replacements so saved v2.x playlists continue to play.

---

## v2.2 — 2026-07-12

High-contrast geometric stock-bank expansion and visual-browser scaling pass.

### Added
- **Ten new mix-ready sources** — Binary Shift, Kinetic Bars, Moiré Orbit, Polar Blades, Radial Crown, Hex Reactor, Iso Stack, Signal Shards, Infinite Frames, and Bauhaus Sequencer.
- **High Contrast and Geometry collections** with monochrome negative space, restrained accent colors, deterministic motion, and BPM-driven spatial movement.
- **Visual category filters** for every bank section plus a PRO shortcut, live result counts, search clearing, keyboard tile activation, and a proper no-results state.

### Changed
- Visual-bank categories are now deliberately ordered for performance use: High Contrast, Geometry, Premium, then the legacy collections.
- Hard-edged geometric thumbnails use PNG encoding to preserve clean lines and prevent JPEG ringing.
- Heavy geometric sources can declare a maximum render rate independently of animation speed.
- Beat response changes geometry, scale, aperture, or stroke rather than using rapid full-screen luminance flashes.

### Performance
- Every new source is deterministic and avoids per-frame randomness.
- Dense hex, isometric, and shard renderers are capped at 30 fps while remaining smooth in the 60 fps mix engine.
- New thumbnails render a single selected frame rather than running the legacy 45-frame warm-up.

---

## v2.1 — 2026-07-12

Performance-console redesign, a curated premium visual pack, signature transition FX, and safer live playlist management.

### Added
- **Four premium live visuals** — Liquid Chrome, Velvet Caustics, Crystal Tunnel, and Topographic Flow. All are procedural, BPM-aware, and render without external stock-media files.
- **Three signature transition FX** — Prism Split, Fluid Wave, and Film Flash.
- **Playlist workspace tools** — per-item play/move/duplicate/remove controls, search, drag insertion feedback, cross-deck copy, and standalone set import/export.
- **Visual library search** with PRO badges and tags for the new curated pack.
- **In-app feedback toasts** for set management actions.

### Changed
- Rebuilt the interface as a modern performance console with clearer hierarchy, improved contrast, larger targets, richer deck identity, and compact responsive behavior.
- Generative visuals now follow the selected 720p/1080p program resolution instead of being permanently rendered at 480p/720p.
- Playlist/session exports omit temporary browser blob URLs that cannot survive a reload.

### Fixed
- Per-deck brightness, contrast, saturation, and hue now reach the master canvas and output window instead of appearing only in deck previews.
- Session settings restore even when a saved deck playlist is empty; playlist indices are clamped and imported items are validated.
- Rapid image cueing no longer allows stale load callbacks to overwrite the newest source.
- Queueing the first item no longer interrupts an ad-hoc visual already playing on that deck.
- Output canvases are no longer resized on every animation frame.

---

## v2.0 — 2026-07-12

Navigation redesign + Free Visuals Bank. Tabbed deck panels, real search, resizable layout, generative visuals, three-state theme.

### Added
- **Free Visuals Bank** — 16 built-in generative visuals, zero media files needed. Ambient (Color Wash, Aurora, Bokeh Drift, Lava Lamp, Ocean Waves), Motion (Starfield, Warp Tunnel, Neon Grid, Hypno Rays), Energy (Plasma, Strobe, Fireworks, Plexus), Retro (Matrix Rain, VHS Static, Kaleidoscope). Click to play, `+` to queue. BPM-reactive (tap tempo drives strobe, fireworks, tunnel pulse, starfield speed). Speed slider controls visual rate. Full output-window sync.
- **Tabbed deck panels** — Browse | Playlist | Visuals per deck. Playlist is now a first-class panel: item count badge, click-to-jump, per-item remove, clear, drag reorder.
- **Search bar per deck** — type to filter the current folder live, Enter runs a deep recursive search of subfolders (new `/api/search` endpoint, depth-limited, 400-result cap, 6s time budget, skips junk dirs). Result rows show relative paths. Load button becomes "Load N Results".
- **Queue buttons** — hover any file row or visual tile for a `+` that appends to the deck playlist without interrupting playback.
- **Resizable layout** — drag the bars between panels to resize deck/center widths, drag under the preview to resize preview height. Double-click a bar to reset, toolbar button resets everything. Layout persists.
- **Breadcrumb path** — every folder segment is clickable. Path input still accepts direct paths.
- **Recent folders menu** — last 10 browsed folders, shared across decks.
- **Transition filter** — search box above the transition picker.
- **Theme: Dark / Light / Auto** — Auto follows the system. Cycle via toolbar or `D`. Light palette rebuilt for contrast.
- **New shortcuts** — `[` / `]` focus Deck A / B search, `D` cycles theme.

### Changed
- Deck media pipeline unified: videos, images, and generative visuals are all playlist items. Slideshow auto-advance applies to visuals too.
- Web edition now uses a threading HTTP server — deep searches and media streaming no longer block each other.
- Static assets served no-cache with versioned URLs — upgrades apply instantly, no stale-JS breakage.
- Drag & drop uses the unified loader (object URLs handled by `loadItem`).

### Fixed
- Output window no longer freezes when the mixer window is hidden/backgrounded — mixer state now also broadcasts on a timer (rAF pauses in background tabs).
- Render health check is actually wired up at startup (was defined but never called in v1.1).
- Transition picker restores the active transition after session load and custom-transition reloads instead of resetting the highlight to Crossfade.

### Distributions
- `Video Mixer v2.0.zip` — Native macOS .app bundle, universal2 (Intel + Apple Silicon)
- `Video Mixer v2.0 - Web.zip` — Cross-platform Python web edition (zero deps)
- `Video Mixer v2.0 - Windows.zip` — Windows portable + .exe build script

---

## v1.1 — 2026-04-25

Stability pass + folder drag/drop + image-stay-on-screen default. Adopted the `vMAJOR.MINOR` versioning convention.

### Added
- **Folder drag & drop from Finder** — drop entire folders onto either deck, recursive scan for media, alphabetical natural sort
- **Drop overlay covers full deck panel** (not just the preview area)
- **Versioning system** — `vX.Y` shown in toolbar, on website, in distribution filenames
- **CHANGELOG.md** to track future releases

### Changed
- **Images stay on screen by default.** Slide slider defaults to OFF, range 0-30. Slideshow mode is opt-in (drag slider above 0).
- **Time display** for images shows just the counter when slideshow is OFF, full progress bar when ON.

### Fixed (stability)
- Object URLs from drag/drop are tracked per deck and revoked when loading a new playlist. No more memory leaks from blob refs.
- Custom transition `<script>` tags are removed before reload. No more pile-up.
- Auto-save no longer writes blob URLs to localStorage.
- AudioContext auto-resumes on focus / visibility change. Survives Chrome's auto-suspend after inactivity.
- Render loop has a stall-detection health check.
- Error retry capped at 5 — playlist won't infinite-loop on broken media.
- Image fade chain releases stale references after fade completes.
- Periodic 30s AudioContext resume guard.

### Distributions
- `Video Mixer v1.1.zip` — Native macOS .app bundle, **universal2** (Intel + Apple Silicon)
- `Video Mixer v1.1 - Web.zip` — Cross-platform Python web edition (zero deps)
- `Video Mixer v1.1 - Windows.zip` — Windows portable + .exe build script

### Build notes
- The Mac .app is built as a universal2 binary. PyInstaller `--target-arch universal2` requires every linked C extension to be a fat binary; we excluded `cffi`, `cryptography`, `numpy`, `pandas`, `PIL`, `pygame`, `pydantic_core`, `rpds`, `matplotlib`, `scipy`, `tkinter` from the bundle since none are used. `markupsafe` was reinstalled with its universal2 wheel.

---

## v1.0 — 2026-04 (initial baseline)

The pre-numbered baseline. Original feature set before the stability + UX pass.

### Features
- Dual deck interface with folder browsing
- 22+ built-in transitions (crossfade, wipes, iris, pixelate, dissolves)
- Dual monitor output via second window with BroadcastChannel sync
- Autopilot mode with configurable hold/transition timing
- VU meters with audio level visualization on each deck
- Save / Load session as JSON
- BPM tap tempo + beat sync (auto-mix on the 4)
- Per-deck FX (brightness, contrast, saturation, hue) with collapsible panel
- Master FX applied to the mix bus
- Custom transitions: drop `.js` files into `~/VideoMixer/transitions/`
- Light / Dark theme toggle
- Auto-save session to localStorage
- Crossfader dead zones at 0/1000 for clean cuts
- Output window audio passthrough with crossfader-aware volume
- Playlist drag-to-reorder
- Fullscreen mode
- Keyboard shortcuts: Q/W play, A/S/K/L next/prev, T tap tempo, P autopilot, etc.
